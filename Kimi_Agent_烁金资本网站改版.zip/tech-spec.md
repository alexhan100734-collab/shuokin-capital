# 汉德资本 - 技术规格

## 依赖

| 包名 | 版本 | 用途 |
|------|------|------|
| react | ^18.2.0 | UI 框架 |
| react-dom | ^18.2.0 | DOM 渲染 |
| three | ^0.160.0 | 3D 引擎（核心特效） |
| @react-three/fiber | ^8.15.0 | React 声明式 Three.js 封装 |
| @react-three/drei | ^9.92.0 | R3F 辅助工具（RoomEnvironment、useTexture 等） |
| gsap | ^3.12.0 | 动画引擎 + ScrollTrigger 插件 |
| lenis | ^1.1.0 | 平滑惯性滚动 |
| vite | ^5.0.0 | 构建工具 |
| @vitejs/plugin-react | ^4.2.0 | React Vite 插件 |
| tailwindcss | ^3.4.0 | 原子化 CSS |
| postcss | ^8.4.0 | CSS 处理 |
| autoprefixer | ^10.4.0 | 浏览器前缀 |

**字体加载**：通过 Google Fonts CDN 引入 Noto Serif SC、Noto Sans SC、Space Grotesk，无需 npm 包。Space Grotesk 作为英文字体直接使用常规 web font 加载即可。

---

## 组件清单

### 布局层

| 组件 | 来源 | 说明 |
|------|------|------|
| CustomCursor | 自建 | 全局自定义光标（3px 白点 + mix-blend-mode: difference），通过 mousemove 事件追踪位置，悬浮可点击元素时放大 |
| BottomNav | 自建 | 底部悬浮导航栏：左侧 Logo + 右侧导航链接（核心业务、独家项目、企业智库、联系我们），Hover 下划线延伸动效 |

### 页面区块

| 组件 | 来源 | 说明 |
|------|------|------|
| HeroSection | 自建 | 全屏视频背景 + 居中偏下宋体标题 + 右侧极细垂直亮线 + 微光粒子 Shader 叠加 |
| MetalTextSection | 自建 | Flythrough Metal Text 3D 穿梭动效容器 + 中文业务哲学文字浮现 |
| WavyTextSection | 自建 | Wavy Text Rows 液态行业流容器，五排英文字母横贯屏幕 |
| DataStreamSection | 自建 | Binary Data Stream 双通道数据流背景 + Glassmorphism 数据卡片 |
| SplitColumnSection | 自建 | Split Column Scroll 三列巨幕滚动 + 字体分裂效果 |
| FooterSection | 自建 | Atmosphere Ring 星云光环背景 + 联系表单 |

### 可复用组件

| 组件 | 来源 | 复用场景 |
|------|------|----------|
| GlassmorphismCard | 自建 | DataStreamSection 中的数据展示卡片（半透明磨砂玻璃质感） |

### Hooks

| Hook | 说明 |
|------|------|
| useLenisVelocity | 封装 Lenis 速度监听，输出平滑后的滚动速度值，供多个 Shader 材质共享 |
| useScrollProgress | 基于 GSAP ScrollTrigger 的滚动进度追踪，返回 0-1 的进度值 |

---

## 动画实现方案

| 动画 | 库 / 插件 | 实现方式 | 复杂度 |
|------|----------|----------|--------|
| 平滑滚动（全局） | Lenis | 在 App 根组件初始化，lerp: 0.08，通过 context 向下传递 velocity | Low |
| Hover 下划线动效 | CSS / GSAP | 伪元素 width 从 0% → 100%，cubic-bezier(0.25, 0.46, 0.45, 0.94) | Low |
| 自定义光标 | GSAP | gsap.to 跟踪鼠标位置，悬浮时 scale 放大 + mix-blend-mode 切换 | Low |
| **Flythrough Metal Text** | Three.js + GSAP | BoxGeometry 分段金属字母，RoomEnvironment 环境贴图，GSAP timeline 编排 z 轴推进 + scale 挤压 + backgroundIntensity 闪烁 | 🔒 High |
| **Wavy Text Rows** | Three.js (R3F) | InstancedMesh + MeshSurfaceSampler 在文字表面采样，自定义 vertex/fragment shader 实现法线照明圆柱体 + 流体波纹，raycaster 鼠标交互 | 🔒 High |
| **Binary Data Stream** | Three.js (R3F) + Canvas 2D | 双 Canvas 预渲染 0/1 位图作为 texture，自定义 vertex shader 根据 scrollSpeed 做 Y 轴拓扑形变，生命周期循环控制 Rising/Falling/Dead 三态 | 🔒 High |
| **Split Column Scroll** | GSAP ScrollTrigger | CSS Grid 三列布局 + 左右 yPercent 错位 + 中列 scale 恢复 + charsArray 分裂动画 + brightness 闪白 | 🔒 High |
| **Atmosphere Ring** | Three.js + EffectComposer | Points 粒子环 + RingShaderMaterial 薄膜干涉 + StarsMaterial 闪烁 + FilmGrainPass 胶片颗粒 + LUT 调色 | 🔒 High |
| Hero 视频播放 | HTML5 Video | autoPlay muted loop playsInline，CSS object-fit: cover | Low |
| 业务哲学文字浮现 | GSAP | 金属字母动画结束后，gsap.from 淡入中文文案 | Low |

---

## 状态与逻辑架构

### Lenis 速度共享

Lenis 实例在 App 根组件创建，通过 React Context 提供：
- `velocity`：实时原始速度
- `smoothedVelocity`：经 lerp(0.05) 平滑后的速度

多个特效组件通过 `useLenisVelocity()` hook 订阅速度值：
- **Atmosphere Ring**：驱动 `scrollSpeed.value`（钳制到 [-0.2, 0.2]）
- **Binary Data Stream**：注入 `u_scrollSpeed` uniform
- **Wavy Text Rows**：通过 lerp 后写入 `uScrollSpeed` 和各实例 `scrollSpeed`

### Three.js 场景管理策略

项目包含 4 个独立 Three.js 场景（MetalText、WavyText、DataStream、AtmosphereRing），各有不同的生命周期和渲染需求：

- **MetalTextSection**：纯 R3F Canvas，随组件 mount/unmount 自动管理
- **WavyTextSection**：R3F Canvas，需要 `useFrame` 驱动 shader uniform 更新
- **DataStreamSection**：R3F Canvas + Canvas 2D 位图预渲染，双纹理输入
- **FooterSection**：原生 Three.js（EffectComposer 需要手动管理 render pass 链），通过 useRef + useEffect 在组件内手动创建 renderer/scene/camera/composer

每个 Canvas 组件设置 `frameloop="always"` 或 `"demand"` 按需控制渲染频率。

### GSAP ScrollTrigger 作用域

所有 ScrollTrigger 动画在各自 section 组件内注册，统一使用 `scrub: true` 实现滚动绑定：
- 组件卸载时调用 `ScrollTrigger.getAll().forEach(t => t.kill())` 清理
- Split Column Scroll 的 `charsArray` 在组件 mount 后通过 DOM ref 分割字符构建

### 字体加载顺序

1. Google Fonts `<link>` 在 `index.html` 头部同步加载
2. `document.fonts.ready` 后触发 MetalText 和 WavyText 的 3D 文本生成（Canvas API 绘制文字纹理需要字体已就绪）
3. 通过 `useFontsReady()` hook 管理全局字体就绪状态
