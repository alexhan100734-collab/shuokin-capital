import { createContext, useContext, useEffect, useRef, useState } from 'react';

interface LenisContextType {
  velocity: number;
  smoothedVelocity: number;
}

export const LenisVelocityContext = createContext<LenisContextType>({
  velocity: 0,
  smoothedVelocity: 0,
});

export function useLenisVelocity() {
  return useContext(LenisVelocityContext);
}

export function LenisVelocityProvider({ children, lenisRef }: { children: React.ReactNode; lenisRef: React.MutableRefObject<any> }) {
  const [velocity, setVelocity] = useState(0);
  const smoothedRef = useRef(0);
  const [smoothedVelocity, setSmoothedVelocity] = useState(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const update = () => {
      if (lenisRef.current) {
        const v = lenisRef.current.velocity || 0;
        setVelocity(v);
        smoothedRef.current += (v - smoothedRef.current) * 0.05;
        setSmoothedVelocity(smoothedRef.current);
      }
      rafRef.current = requestAnimationFrame(update);
    };
    rafRef.current = requestAnimationFrame(update);
    return () => cancelAnimationFrame(rafRef.current);
  }, [lenisRef]);

  return (
    <LenisVelocityContext.Provider value={{ velocity, smoothedVelocity }}>
      {children}
    </LenisVelocityContext.Provider>
  );
}
