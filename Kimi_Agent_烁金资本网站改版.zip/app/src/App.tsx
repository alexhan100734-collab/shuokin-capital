import { useEffect, useRef, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { LenisVelocityProvider } from './hooks/useLenisVelocity';
import CustomCursor from './components/CustomCursor';
import BottomNav from './components/BottomNav';
import HomePage from './pages/HomePage';
import MergersPage from './pages/MergersPage';
import FinancingPage from './pages/FinancingPage';
import CommercialPage from './pages/CommercialPage';
import NotFound from './pages/NotFound';
import AdminPanel from './components/AdminPanel';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const lenisRef = useRef<Lenis | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);

  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.08, smoothWheel: true });
    lenisRef.current = lenis;
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => { lenis.raf(time * 1000); });
    gsap.ticker.lagSmoothing(0);
    return () => { lenis.destroy(); };
  }, []);

  return (
    <LenisVelocityProvider lenisRef={lenisRef as React.MutableRefObject<any>}>
      <CustomCursor />
      {!showAdmin && <BottomNav />}
      <main style={{ background: '#05050A', minHeight: '100vh' }}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/mergers" element={<MergersPage />} />
          <Route path="/financing" element={<FinancingPage />} />
          <Route path="/commercial" element={<CommercialPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      {/* Admin Panel - accessible from any page */}
      <AdminPanel visible={showAdmin} onClose={() => setShowAdmin(false)} />

      {/* Admin toggle button - always visible */}
      <button
        onClick={() => setShowAdmin(!showAdmin)}
        style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          zIndex: 99999,
          padding: '8px 16px',
          background: 'rgba(10,10,18,0.8)',
          border: '1px solid rgba(232,228,224,0.15)',
          borderRadius: '4px',
          color: '#8A8A9A',
          fontSize: '11px',
          letterSpacing: '0.1em',
          cursor: 'pointer',
          backdropFilter: 'blur(10px)',
        }}
      >
        {showAdmin ? '关闭管理' : '管理'}
      </button>
    </LenisVelocityProvider>
  );
}
