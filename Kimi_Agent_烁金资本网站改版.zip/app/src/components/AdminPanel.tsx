import { useState, useEffect } from "react";

const TYPE_COLORS: Record<string, string> = {
  "并购": "#C0392B",
  "融资": "#F4D03F",
  "融商": "#1ABC9C",
};

const STATUS_COLORS: Record<string, string> = {
  "已完成": "#1ABC9C",
  "进行中": "#F4D03F",
  "已终止": "#8A8A9A",
};

interface Project {
  id: number;
  name: string;
  type: "并购" | "融资" | "融商";
  industry: string;
  value: string;
  status: "已完成" | "进行中" | "已终止";
  description: string;
  createdAt: string;
}

interface Partner {
  id: number;
  name: string;
  enName: string;
  description: string;
  createdAt: string;
}

interface AdminPanelProps {
  visible: boolean;
  onClose: () => void;
}

// Seed data
const DEFAULT_PROJECTS: Project[] = [
  { id: 1, name: "某新能源电池企业收购案", type: "并购", industry: "新能源", value: "3.2亿元", status: "已完成", description: "", createdAt: "2024-01-15" },
  { id: 2, name: "AI芯片企业A轮融资", type: "融资", industry: "半导体", value: "2亿元", status: "进行中", description: "", createdAt: "2024-02-20" },
  { id: 3, name: "精密制造产业链整合", type: "并购", industry: "先进制造", value: "1.8亿元", status: "进行中", description: "", createdAt: "2024-03-10" },
  { id: 4, name: "生物医药企业B轮融资", type: "融资", industry: "医疗", value: "3.5亿元", status: "已完成", description: "", createdAt: "2024-01-28" },
  { id: 5, name: "医疗器械跨境收购", type: "并购", industry: "医疗", value: "5000万美元", status: "已完成", description: "", createdAt: "2024-02-05" },
  { id: 6, name: "消费品牌战略合作", type: "融商", industry: "消费", value: "战略合作", status: "进行中", description: "", createdAt: "2024-03-18" },
];

const DEFAULT_PARTNERS: Partner[] = [
  { id: 1, name: "优势资本", enName: "ADVANTAGE CAPITAL", description: "中国领先的私募股权投资基金，专注于成长期企业股权投资。", createdAt: "2024-01-01" },
  { id: 2, name: "红杉资本", enName: "SEQUOIA CAPITAL", description: "全球顶级风险投资机构，投资了众多科技创新企业。", createdAt: "2024-01-01" },
  { id: 3, name: "高盛资本", enName: "GOLDMAN SACHS", description: "全球领先的投资银行与金融服务机构，提供全方位资本市场服务。", createdAt: "2024-01-01" },
  { id: 4, name: "IDG资本", enName: "IDG CAPITAL", description: "中国最早的风险投资机构之一，深耕科技与消费领域。", createdAt: "2024-01-01" },
  { id: 5, name: "深创投", enName: "SCGC", description: "中国本土最大的创投机构之一，专注于高新技术领域投资。", createdAt: "2024-01-01" },
  { id: 6, name: "中金资本", enName: "CICC CAPITAL", description: "中国国际金融股份有限公司旗下私募股权投资平台。", createdAt: "2024-01-01" },
];

function loadProjects(): Project[] {
  try {
    const raw = localStorage.getItem("shuokin_projects");
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  localStorage.setItem("shuokin_projects", JSON.stringify(DEFAULT_PROJECTS));
  return DEFAULT_PROJECTS;
}

function saveProjects(list: Project[]) {
  localStorage.setItem("shuokin_projects", JSON.stringify(list));
  window.dispatchEvent(new CustomEvent("shuokin-data-changed"));
}

function loadPartners(): Partner[] {
  try {
    const raw = localStorage.getItem("shuokin_partners");
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  localStorage.setItem("shuokin_partners", JSON.stringify(DEFAULT_PARTNERS));
  return DEFAULT_PARTNERS;
}

function savePartners(list: Partner[]) {
  localStorage.setItem("shuokin_partners", JSON.stringify(list));
  window.dispatchEvent(new CustomEvent("shuokin-data-changed"));
}

export default function AdminPanel({ visible, onClose }: AdminPanelProps) {
  const [tab, setTab] = useState<"projects" | "partners">("projects");
  const [projects, setProjects] = useState<Project[]>(loadProjects);
  const [partners, setPartners] = useState<Partner[]>(loadPartners);

  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  const [projForm, setProjForm] = useState({
    name: "", type: "并购" as "并购" | "融资" | "融商",
    industry: "", value: "", status: "进行中" as "进行中" | "已完成" | "已终止",
    description: "",
  });
  const [partForm, setPartForm] = useState({ name: "", enName: "", description: "" });

  // Sync to localStorage whenever data changes
  useEffect(() => { saveProjects(projects); }, [projects]);
  useEffect(() => { savePartners(partners); }, [partners]);

  const resetProjForm = () => setProjForm({ name: "", type: "并购", industry: "", value: "", status: "进行中", description: "" });
  const resetPartForm = () => setPartForm({ name: "", enName: "", description: "" });

  const handleProjSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editId) {
      setProjects(prev => prev.map(p => p.id === editId ? { ...p, ...projForm } : p));
      setEditId(null);
    } else {
      const newProj: Project = {
        id: Date.now(),
        ...projForm,
        createdAt: new Date().toISOString().split("T")[0],
      };
      setProjects(prev => [newProj, ...prev]);
    }
    setShowForm(false);
    resetProjForm();
  };

  const handlePartSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editId) {
      setPartners(prev => prev.map(p => p.id === editId ? { ...p, ...partForm } : p));
      setEditId(null);
    } else {
      const newPart: Partner = {
        id: Date.now(),
        ...partForm,
        createdAt: new Date().toISOString().split("T")[0],
      };
      setPartners(prev => [newPart, ...prev]);
    }
    setShowForm(false);
    resetPartForm();
  };

  const handleDeleteProj = (id: number) => {
    if (confirm("确定删除此项目？")) setProjects(prev => prev.filter(p => p.id !== id));
  };

  const handleDeletePart = (id: number) => {
    if (confirm("确定删除此合作伙伴？")) setPartners(prev => prev.filter(p => p.id !== id));
  };

  const startEditProj = (p: Project) => {
    setProjForm({ name: p.name, type: p.type, industry: p.industry, value: p.value, status: p.status, description: p.description });
    setEditId(p.id);
    setShowForm(true);
  };

  const startEditPart = (p: Partner) => {
    setPartForm({ name: p.name, enName: p.enName, description: p.description });
    setEditId(p.id);
    setShowForm(true);
  };

  if (!visible) return null;

  return (
    <div style={{
      position: "fixed", top: 0, right: 0, width: "520px", maxWidth: "100vw",
      height: "100vh", background: "#0A0A12", borderLeft: "1px solid rgba(232,228,224,0.1)",
      zIndex: 99998, display: "flex", flexDirection: "column", overflow: "hidden",
    }}>
      {/* Header */}
      <div style={{
        padding: "20px 24px", borderBottom: "1px solid rgba(232,228,224,0.1)",
        display: "flex", justifyContent: "space-between", alignItems: "center",
      }}>
        <div>
          <span className="font-en" style={{ fontSize: "13px", fontWeight: 700, color: "#E8E4E0", letterSpacing: "0.1em" }}>
            SHUOKIN
          </span>
          <span style={{ fontSize: "11px", color: "#8A8A9A", marginLeft: "12px" }}>管理后台</span>
        </div>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "#8A8A9A", fontSize: "18px", cursor: "pointer" }}>
          ✕
        </button>
      </div>

      {/* Storage notice */}
      <div style={{
        padding: "10px 24px", background: "rgba(26,188,156,0.08)",
        borderBottom: "1px solid rgba(26,188,156,0.15)",
      }}>
        <p style={{ fontSize: "11px", color: "#1ABC9C" }}>
          ✅ 数据保存在浏览器本地。换电脑/清缓存会丢失，建议定期备份。
        </p>
      </div>

      {/* Stats */}
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1px",
        background: "rgba(232,228,224,0.06)", padding: "16px 24px",
      }}>
        {[
          { label: "项目", value: projects.length },
          { label: "并购", value: projects.filter(p => p.type === "并购").length },
          { label: "融资", value: projects.filter(p => p.type === "融资").length },
          { label: "伙伴", value: partners.length },
        ].map(s => (
          <div key={s.label} style={{ textAlign: "center" }}>
            <div className="font-en" style={{ fontSize: "20px", fontWeight: 700, color: "#E8E4E0" }}>{s.value}</div>
            <div style={{ fontSize: "10px", color: "#8A8A9A", marginTop: "2px" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid rgba(232,228,224,0.08)" }}>
        {(["projects", "partners"] as const).map((t) => (
          <button key={t} onClick={() => { setTab(t); setShowForm(false); setEditId(null); }}
            style={{
              flex: 1, padding: "12px", background: tab === t ? "rgba(232,228,224,0.06)" : "transparent",
              border: "none", borderBottom: tab === t ? "2px solid #E8E4E0" : "2px solid transparent",
              color: tab === t ? "#E8E4E0" : "#8A8A9A", fontSize: "12px", letterSpacing: "0.1em", cursor: "pointer",
            }}>
            {t === "projects" ? "项目管理" : "合作伙伴"}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {tab === "projects" ? (
          <div>
            <button onClick={() => { setShowForm(!showForm); setEditId(null); resetProjForm(); }}
              style={{
                width: "100%", padding: "10px", marginBottom: "16px",
                background: "rgba(232,228,224,0.05)", border: "1px dashed rgba(232,228,224,0.2)",
                borderRadius: "4px", color: "#8A8A9A", fontSize: "12px", cursor: "pointer",
              }}>
              {showForm ? "取消" : "+ 新增项目"}
            </button>

            {showForm && (
              <form onSubmit={handleProjSubmit} style={{
                padding: "16px", background: "rgba(5,5,10,0.6)", borderRadius: "4px",
                marginBottom: "16px", display: "flex", flexDirection: "column", gap: "10px",
              }}>
                <h4 style={{ fontSize: "14px", color: "#E8E4E0", marginBottom: "4px" }}>
                  {editId ? "编辑项目" : "新增项目"}
                </h4>
                <input placeholder="项目名称 *" value={projForm.name} onChange={e => setProjForm({ ...projForm, name: e.target.value })} style={inputStyle} required />
                <div style={{ display: "flex", gap: "8px" }}>
                  <select value={projForm.type} onChange={e => setProjForm({ ...projForm, type: e.target.value as "并购" | "融资" | "融商" })} style={{ ...inputStyle, flex: 1 }}>
                    <option value="并购">并购</option>
                    <option value="融资">融资</option>
                    <option value="融商">融商</option>
                  </select>
                  <select value={projForm.status} onChange={e => setProjForm({ ...projForm, status: e.target.value as "进行中" | "已完成" | "已终止" })} style={{ ...inputStyle, flex: 1 }}>
                    <option value="进行中">进行中</option>
                    <option value="已完成">已完成</option>
                    <option value="已终止">已终止</option>
                  </select>
                </div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <input placeholder="行业 *" value={projForm.industry} onChange={e => setProjForm({ ...projForm, industry: e.target.value })} style={{ ...inputStyle, flex: 1 }} required />
                  <input placeholder="规模 * 如：3.2亿元" value={projForm.value} onChange={e => setProjForm({ ...projForm, value: e.target.value })} style={{ ...inputStyle, flex: 1 }} required />
                </div>
                <textarea placeholder="项目描述（可选）" value={projForm.description} onChange={e => setProjForm({ ...projForm, description: e.target.value })} style={{ ...inputStyle, minHeight: "60px", resize: "vertical" }} />
                <button type="submit" style={{
                  padding: "8px 16px", background: "rgba(244,208,63,0.15)", border: "1px solid rgba(244,208,63,0.3)",
                  borderRadius: "4px", color: "#F4D03F", fontSize: "12px", cursor: "pointer",
                }}>
                  {editId ? "保存修改" : "创建项目"}
                </button>
              </form>
            )}

            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {projects.map(p => (
                <div key={p.id} style={{
                  padding: "14px", background: "rgba(5,5,10,0.4)", borderRadius: "4px",
                  border: "1px solid rgba(232,228,224,0.06)",
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ fontSize: "14px", color: "#E8E4E0", marginBottom: "4px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</p>
                      <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
                        <span style={{ fontSize: "11px", color: TYPE_COLORS[p.type], fontWeight: 500 }}>{p.type}</span>
                        <span style={{ fontSize: "11px", color: "#8A8A9A" }}>{p.industry}</span>
                        <span className="font-en" style={{ fontSize: "12px", color: "#F4D03F" }}>{p.value}</span>
                        <span style={{ fontSize: "11px", color: STATUS_COLORS[p.status] }}>{p.status}</span>
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: "8px", marginLeft: "8px", flexShrink: 0 }}>
                      <button onClick={() => startEditProj(p)} style={linkBtn}>编辑</button>
                      <button onClick={() => handleDeleteProj(p.id)} style={{ ...linkBtn, color: "#C0392B" }}>删除</button>
                    </div>
                  </div>
                  {p.description && <p style={{ fontSize: "12px", color: "#8A8A9A", marginTop: "6px" }}>{p.description}</p>}
                </div>
              ))}
              {projects.length === 0 && <p style={{ color: "#8A8A9A", textAlign: "center", padding: "20px" }}>暂无项目</p>}
            </div>
          </div>
        ) : (
          <div>
            <button onClick={() => { setShowForm(!showForm); setEditId(null); resetPartForm(); }}
              style={{
                width: "100%", padding: "10px", marginBottom: "16px",
                background: "rgba(232,228,224,0.05)", border: "1px dashed rgba(232,228,224,0.2)",
                borderRadius: "4px", color: "#8A8A9A", fontSize: "12px", cursor: "pointer",
              }}>
              {showForm ? "取消" : "+ 新增伙伴"}
            </button>

            {showForm && (
              <form onSubmit={handlePartSubmit} style={{
                padding: "16px", background: "rgba(5,5,10,0.6)", borderRadius: "4px",
                marginBottom: "16px", display: "flex", flexDirection: "column", gap: "10px",
              }}>
                <h4 style={{ fontSize: "14px", color: "#E8E4E0", marginBottom: "4px" }}>
                  {editId ? "编辑合作伙伴" : "新增合作伙伴"}
                </h4>
                <input placeholder="中文名称 *" value={partForm.name} onChange={e => setPartForm({ ...partForm, name: e.target.value })} style={inputStyle} required />
                <input placeholder="英文名称 *" value={partForm.enName} onChange={e => setPartForm({ ...partForm, enName: e.target.value })} style={inputStyle} required />
                <textarea placeholder="描述（可选）" value={partForm.description} onChange={e => setPartForm({ ...partForm, description: e.target.value })} style={{ ...inputStyle, minHeight: "60px", resize: "vertical" }} />
                <button type="submit" style={{
                  padding: "8px 16px", background: "rgba(244,208,63,0.15)", border: "1px solid rgba(244,208,63,0.3)",
                  borderRadius: "4px", color: "#F4D03F", fontSize: "12px", cursor: "pointer",
                }}>
                  {editId ? "保存修改" : "创建"}
                </button>
              </form>
            )}

            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {partners.map(p => (
                <div key={p.id} style={{
                  padding: "14px", background: "rgba(5,5,10,0.4)", borderRadius: "4px",
                  border: "1px solid rgba(232,228,224,0.06)",
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ fontSize: "14px", color: "#E8E4E0", marginBottom: "2px" }}>{p.name}</p>
                      <p style={{ fontSize: "10px", color: "#8A8A9A", letterSpacing: "0.1em" }}>{p.enName}</p>
                    </div>
                    <div style={{ display: "flex", gap: "8px", marginLeft: "8px", flexShrink: 0 }}>
                      <button onClick={() => startEditPart(p)} style={linkBtn}>编辑</button>
                      <button onClick={() => handleDeletePart(p.id)} style={{ ...linkBtn, color: "#C0392B" }}>删除</button>
                    </div>
                  </div>
                  {p.description && <p style={{ fontSize: "12px", color: "#8A8A9A", marginTop: "6px", lineHeight: 1.5 }}>{p.description}</p>}
                </div>
              ))}
              {partners.length === 0 && <p style={{ color: "#8A8A9A", textAlign: "center", padding: "20px" }}>暂无合作伙伴</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  padding: "8px 12px", background: "rgba(5,5,10,0.6)", border: "1px solid rgba(232,228,224,0.12)",
  borderRadius: "4px", color: "#E8E4E0", fontSize: "12px", outline: "none", width: "100%",
};

const linkBtn: React.CSSProperties = {
  color: "#8A8A9A", background: "none", border: "none", cursor: "pointer",
  padding: 0, textDecoration: "underline", fontSize: "11px",
};
