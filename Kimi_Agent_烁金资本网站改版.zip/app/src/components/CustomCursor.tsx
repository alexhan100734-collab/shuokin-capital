import { useEffect, useRef } from 'react';
import gsap from 'gsap';

export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const posRef = useRef({ x: 0, y: 0 });
  const isHoveringRef = useRef(false);

  useEffect(() => {
    const dot = dotRef.current;
    if (!dot) return;

    const onMove = (e: MouseEvent) => {
      posRef.current.x = e.clientX;
      posRef.current.y = e.clientY;
      gsap.to(dot, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.08,
        ease: 'power2.out',
      });
    };

    const onEnterInteractive = () => {
      if (isHoveringRef.current) return;
      isHoveringRef.current = true;
      gsap.to(dot, {
        scale: 4,
        duration: 0.3,
        ease: 'power2.out',
      });
      dot.style.mixBlendMode = 'difference';
    };

    const onLeaveInteractive = () => {
      isHoveringRef.current = false;
      gsap.to(dot, {
        scale: 1,
        duration: 0.3,
        ease: 'power2.out',
      });
      dot.style.mixBlendMode = 'normal';
    };

    window.addEventListener('mousemove', onMove);

    const addHoverListeners = () => {
      const interactives = document.querySelectorAll('a, button, input, textarea, [data-cursor-hover], canvas');
      interactives.forEach((el) => {
        el.addEventListener('mouseenter', onEnterInteractive);
        el.addEventListener('mouseleave', onLeaveInteractive);
      });
    };

    // Delay to let DOM settle
    const timeout = setTimeout(addHoverListeners, 1000);
    const observer = new MutationObserver(addHoverListeners);
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      window.removeEventListener('mousemove', onMove);
      clearTimeout(timeout);
      observer.disconnect();
    };
  }, []);

  return (
    <div
      ref={dotRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '3px',
        height: '3px',
        backgroundColor: '#fff',
        borderRadius: '50%',
        pointerEvents: 'none',
        zIndex: 99999,
        transform: 'translate(-50%, -50%)',
        willChange: 'transform',
      }}
    />
  );
}
