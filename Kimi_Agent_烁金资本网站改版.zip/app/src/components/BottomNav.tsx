import { useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import gsap from 'gsap';

const NAV_ITEMS = [
  { label: '首页', href: '/' },
  { label: '并购', href: '/mergers' },
  { label: '融资', href: '/financing' },
  { label: '融商', href: '/commercial' },
  { label: '企业智库', href: '/#intelligence' },
  { label: '联系我们', href: '/#contact' },
];

export default function BottomNav() {
  const navRef = useRef<HTMLElement>(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (!navRef.current) return;
    gsap.fromTo(
      navRef.current,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 1.2, delay: 0.5, ease: 'power3.out' }
    );
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    if (href.startsWith('/#')) {
      // Hash link on homepage
      if (location.pathname !== '/') {
        navigate('/');
        setTimeout(() => {
          const id = href.replace('/#', '');
          const target = document.getElementById(id);
          if (target) target.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        const id = href.replace('/#', '');
        const target = document.getElementById(id);
        if (target) target.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigate(href);
    }
  };

  return (
    <nav
      ref={navRef}
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        padding: '20px 32px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        background: 'linear-gradient(to top, rgba(5,5,10,0.95) 0%, rgba(5,5,10,0.6) 60%, transparent 100%)',
        opacity: 0,
      }}
    >
      <a
        href="/"
        onClick={(e) => { e.preventDefault(); navigate('/'); }}
        className="font-en"
        style={{
          fontSize: '14px',
          fontWeight: 700,
          color: '#E8E4E0',
          letterSpacing: '0.15em',
          textDecoration: 'none',
        }}
      >
        SHUOKIN CAPITAL
      </a>
      <div style={{ display: 'flex', gap: '24px', alignItems: 'center' }}>
        {NAV_ITEMS.map((item) => (
          <a
            key={item.href}
            href={item.href}
            onClick={(e) => handleClick(e, item.href)}
            className="nav-link font-ui"
            style={{
              fontSize: '12px',
              fontWeight: 400,
              letterSpacing: '0.08em',
              textDecoration: 'none',
            }}
          >
            {item.label}
          </a>
        ))}
      </div>
    </nav>
  );
}
