import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";

const NAV_ITEMS = [
  { label: "仪表盘", href: "/admin" },
  { label: "项目管理", href: "/admin/projects" },
  { label: "合作伙伴", href: "/admin/partners" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/login?redirect=/admin");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "center",
        height: "100vh", background: "#05050A", color: "#8A8A9A",
      }}>
        加载中...
      </div>
    );
  }

  if (!user) return null;

  return (
    <div style={{
      display: "flex",
      minHeight: "100vh",
      background: "#05050A",
      color: "#E8E4E0",
    }}>
      {/* Sidebar */}
      <aside style={{
        width: "220px",
        background: "#0A0A12",
        borderRight: "1px solid rgba(232,228,224,0.08)",
        padding: "32px 0",
        display: "flex",
        flexDirection: "column",
        position: "fixed",
        top: 0,
        left: 0,
        bottom: 0,
        zIndex: 100,
      }}>
        {/* Logo */}
        <div style={{ padding: "0 24px", marginBottom: "40px" }}>
          <Link to="/" style={{ textDecoration: "none" }}>
            <span className="font-en" style={{
              fontSize: "14px", fontWeight: 700, color: "#E8E4E0",
              letterSpacing: "0.1em",
            }}>
              SHUOKIN
            </span>
          </Link>
          <p style={{
            fontSize: "10px", color: "#8A8A9A", marginTop: "4px",
            letterSpacing: "0.05em",
          }}>
            管理后台
          </p>
        </div>

        {/* Nav */}
        <nav style={{ display: "flex", flexDirection: "column", gap: "4px", padding: "0 12px" }}>
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link
                key={item.href}
                to={item.href}
                style={{
                  padding: "10px 16px",
                  borderRadius: "4px",
                  fontSize: "13px",
                  color: isActive ? "#E8E4E0" : "#8A8A9A",
                  background: isActive ? "rgba(232,228,224,0.06)" : "transparent",
                  textDecoration: "none",
                  transition: "all 0.2s ease",
                  letterSpacing: "0.05em",
                }}
                onMouseEnter={(e) => {
                  if (!isActive) e.currentTarget.style.background = "rgba(232,228,224,0.03)";
                }}
                onMouseLeave={(e) => {
                  if (!isActive) e.currentTarget.style.background = "transparent";
                }}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* User info */}
        <div style={{
          marginTop: "auto",
          padding: "16px 24px",
          borderTop: "1px solid rgba(232,228,224,0.08)",
        }}>
          <p style={{ fontSize: "12px", color: "#E8E4E0" }}>{user.name || "管理员"}</p>
          <Link
            to="/"
            style={{
              fontSize: "11px", color: "#8A8A9A", textDecoration: "none",
              marginTop: "8px", display: "inline-block",
            }}
          >
            ← 返回前台
          </Link>
        </div>
      </aside>

      {/* Main content */}
      <main style={{
        flex: 1,
        marginLeft: "220px",
        padding: "40px",
        minHeight: "100vh",
      }}>
        {children}
      </main>
    </div>
  );
}
