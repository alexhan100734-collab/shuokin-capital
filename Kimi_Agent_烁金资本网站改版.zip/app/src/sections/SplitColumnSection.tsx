import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const IMAGES = [
  ['/images/chip.jpg', '/images/architecture.jpg', '/images/fluid.jpg', '/images/robot.jpg'],
  ['/images/architecture.jpg', '/images/fluid.jpg', '/images/chip.jpg', '/images/robot.jpg'],
  ['/images/robot.jpg', '/images/chip.jpg', '/images/architecture.jpg', '/images/fluid.jpg'],
];

export default function SplitColumnSection() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const charsRef = useRef<HTMLSpanElement[]>([]);

  useEffect(() => {
    if (!wrapRef.current || !contentRef.current) return;

    const wrap = wrapRef.current;
    const columns = contentRef.current.querySelectorAll<HTMLDivElement>('.column');
    const leftCol = columns[0];
    const centerCol = columns[1];
    const rightCol = columns[2];
    const centerImages = centerCol.querySelectorAll<HTMLDivElement>('.col-img-wrap');

    const triggers: ScrollTrigger[] = [];

    // Left column scrolls up
    const tl1 = gsap.to(leftCol, {
      yPercent: -40,
      ease: 'none',
      scrollTrigger: {
        trigger: wrap,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true,
      },
    });
    if (tl1.scrollTrigger) triggers.push(tl1.scrollTrigger);

    // Right column scrolls down
    const tl2 = gsap.to(rightCol, {
      yPercent: 40,
      ease: 'none',
      scrollTrigger: {
        trigger: wrap,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true,
      },
    });
    if (tl2.scrollTrigger) triggers.push(tl2.scrollTrigger);

    // Center column - scale + opacity
    centerImages.forEach((img) => {
      const tl3 = gsap.fromTo(
        img,
        { scaleY: 1.5, scaleX: 0.8, opacity: 0.5 },
        {
          scaleY: 1,
          scaleX: 1,
          opacity: 1,
          ease: 'none',
          scrollTrigger: {
            trigger: wrap,
            start: 'top 60%',
            end: 'center center',
            scrub: true,
          },
        }
      );
      if (tl3.scrollTrigger) triggers.push(tl3.scrollTrigger);
    });

    // Character split animation
    const chars = charsRef.current.filter(Boolean);
    const charsTotal = chars.length;
    const mid = Math.floor(charsTotal / 2);

    const leftChars = chars.slice(0, mid);
    const rightChars = chars.slice(mid);

    if (leftChars.length > 0) {
      const tl4 = gsap.to(leftChars, {
        xPercent: (i: number) => -(30 * (mid - 1 - i) + 15),
        stagger: { amount: 0.15, from: 'start' },
        ease: 'none',
        scrollTrigger: {
          trigger: wrap,
          start: 'clamp(top bottom)',
          end: '+=40%',
          scrub: true,
        },
      });
      if (tl4.scrollTrigger) triggers.push(tl4.scrollTrigger);
    }

    if (rightChars.length > 0) {
      const tl5 = gsap.to(rightChars, {
        xPercent: (i: number) => 30 * i + 15,
        stagger: { amount: 0.15, from: 'start' },
        ease: 'none',
        scrollTrigger: {
          trigger: wrap,
          start: 'clamp(top bottom)',
          end: '+=40%',
          scrub: true,
        },
      });
      if (tl5.scrollTrigger) triggers.push(tl5.scrollTrigger);
    }

    // Flash white effect
    const tl6 = gsap.fromTo(
      wrap,
      { filter: 'brightness(300%)' },
      {
        filter: 'brightness(100%)',
        ease: 'sine.inOut',
        scrollTrigger: {
          trigger: wrap,
          start: 'clamp(top bottom)',
          end: 'top top',
          scrub: true,
        },
      }
    );
    if (tl6.scrollTrigger) triggers.push(tl6.scrollTrigger);

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  const titleText = 'PROJECTS';

  return (
    <section
      id="projects"
      style={{
        position: 'relative',
        margin: '20vh 0',
      }}
    >
      {/* Section title with split chars */}
      <div
        ref={titleRef}
        style={{
          position: 'relative',
          textAlign: 'center',
          padding: '60px 0 20px',
          zIndex: 5,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
            marginBottom: '16px',
          }}
        >
          Featured Deals
        </p>
        <div
          className="font-en"
          style={{
            fontSize: 'clamp(48px, 10vw, 120px)',
            fontWeight: 700,
            color: '#E8E4E0',
            letterSpacing: '0.15em',
            display: 'flex',
            justifyContent: 'center',
            overflow: 'hidden',
          }}
        >
          {titleText.split('').map((char, i) => (
            <span
              key={i}
              ref={(el) => {
                if (el) charsRef.current[i] = el;
              }}
              style={{ display: 'inline-block', willChange: 'transform' }}
            >
              {char}
            </span>
          ))}
        </div>
      </div>

      {/* Three-column scroll container */}
      <div
        ref={wrapRef}
        className="wrap"
        style={{
          position: 'relative',
          width: '100%',
          height: '100vh',
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto',
          willChange: 'transform',
        }}
      >
        <div
          ref={contentRef}
          style={{
            position: 'absolute',
            width: '100%',
            height: '100%',
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '2rem',
            padding: '2rem',
            alignItems: 'start',
          }}
        >
          {IMAGES.map((colImages, colIdx) => (
            <div
              key={colIdx}
              className="column"
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '2rem',
                marginTop: colIdx === 0 ? '-10vh' : colIdx === 2 ? '10vh' : '0',
              }}
            >
              {colImages.map((src, imgIdx) => (
                <div
                  key={imgIdx}
                  className="col-img-wrap"
                  style={{
                    width: colIdx === 1 ? '30vw' : '20vw',
                    height: colIdx === 1 ? '35vw' : '25vw',
                    overflow: 'hidden',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    backgroundImage: `url(${src})`,
                    willChange: 'transform, opacity',
                  }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
