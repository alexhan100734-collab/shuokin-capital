import { useEffect, useRef } from 'react';
import gsap from 'gsap';

export default function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const tagRef = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ delay: 0.3 });

    tl.fromTo(
      titleRef.current,
      { opacity: 0, y: 60 },
      { opacity: 1, y: 0, duration: 1.8, ease: 'power3.out' }
    )
      .fromTo(
        lineRef.current,
        { scaleY: 0 },
        { scaleY: 1, duration: 1.2, ease: 'power2.inOut' },
        '-=1.2'
      )
      .fromTo(
        subtitleRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1.4, ease: 'power2.out' },
        '-=0.6'
      )
      .fromTo(
        tagRef.current,
        { opacity: 0, y: 10 },
        { opacity: 1, y: 0, duration: 1, ease: 'power2.out' },
        '-=0.4'
      );

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      style={{
        position: 'relative',
        width: '100%',
        height: '100vh',
        overflow: 'hidden',
        background: '#05050A',
      }}
    >
      {/* Video Background */}
      <video
        autoPlay
        muted
        loop
        playsInline
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          opacity: 0.7,
        }}
      >
        <source src="/videos/hero.mp4" type="video/mp4" />
      </video>

      {/* Gradient overlay */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'linear-gradient(to bottom, rgba(5,5,10,0.3) 0%, rgba(5,5,10,0.1) 40%, rgba(5,5,10,0.7) 100%)',
          pointerEvents: 'none',
        }}
      />

      {/* Vertical line divider */}
      <div
        ref={lineRef}
        style={{
          position: 'absolute',
          top: '15%',
          left: '50%',
          width: '1px',
          height: '70%',
          background: 'linear-gradient(to bottom, transparent, rgba(232,228,224,0.4), transparent)',
          transformOrigin: 'top center',
          zIndex: 2,
        }}
      />

      {/* Title block */}
      <div
        style={{
          position: 'absolute',
          bottom: '20%',
          left: '50%',
          transform: 'translateX(-50%)',
          textAlign: 'center',
          zIndex: 3,
          maxWidth: '900px',
          padding: '0 40px',
        }}
      >
        <h1
          ref={titleRef}
          className="font-display"
          style={{
            fontSize: 'clamp(32px, 5vw, 56px)',
            fontWeight: 900,
            color: '#E8E4E0',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            marginBottom: '20px',
            opacity: 0,
            textShadow: '0 2px 40px rgba(0,0,0,0.5)',
          }}
        >
          洞见产业脉搏，重塑资本边界
        </h1>
        <p
          ref={subtitleRef}
          className="font-ui"
          style={{
            fontSize: 'clamp(14px, 1.4vw, 18px)',
            fontWeight: 400,
            color: '#8A8A9A',
            letterSpacing: '0.1em',
            lineHeight: 1.8,
            opacity: 0,
            marginBottom: '16px',
          }}
        >
          专注中国中小企业并购与投融资服务
        </p>
        <p
          ref={tagRef}
          className="font-ui"
          style={{
            fontSize: 'clamp(11px, 1vw, 13px)',
            fontWeight: 400,
            color: 'rgba(138,138,154,0.6)',
            letterSpacing: '0.15em',
            opacity: 0,
          }}
        >
          烁金资本 · SHUOKIN Capital · 深圳 · 上海 · 香港
        </p>
      </div>

      {/* Particle overlay (subtle) */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          right: 0,
          width: '50%',
          height: '100%',
          background: 'radial-gradient(ellipse at 80% 50%, rgba(100,100,200,0.03) 0%, transparent 70%)',
          pointerEvents: 'none',
          zIndex: 1,
        }}
      />
    </section>
  );
}
