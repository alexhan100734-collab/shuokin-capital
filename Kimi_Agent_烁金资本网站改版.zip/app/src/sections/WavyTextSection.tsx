import { useEffect, useRef } from 'react';
import { useLenisVelocity } from '../hooks/useLenisVelocity';

const ROWS = [
  { text: 'ADVANCED MANUFACTURING', speed: 0.3, color: '#C0392B', yOffset: 0 },
  { text: 'SEMICONDUCTORS & AI', speed: 0.5, color: '#F4D03F', yOffset: 1 },
  { text: 'NEW ENERGY VEHICLES', speed: 0.4, color: '#1ABC9C', yOffset: 2 },
  { text: 'BIO-PHARMACEUTICALS', speed: 0.35, color: '#E8E4E0', yOffset: 3 },
  { text: 'CONSUMER BRANDS', speed: 0.45, color: '#8A8A9A', yOffset: 4 },
];

function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

export default function WavyTextSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const scrollOffsetRef = useRef(0);
  const mouseRef = useRef({ x: -1000, y: -1000 });
  const sectionRef = useRef<HTMLDivElement>(null);
  const { smoothedVelocity } = useLenisVelocity();
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) return;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener('resize', resize);

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.x = e.clientX - rect.left;
      mouseRef.current.y = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
      mouseRef.current.x = -1000;
      mouseRef.current.y = -1000;
    };

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseleave', handleMouseLeave);

    let time = 0;

    const draw = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) {
        rafRef.current = requestAnimationFrame(draw);
        return;
      }

      const w = rect.width;
      const h = rect.height;

      ctx.clearRect(0, 0, w, h);

      scrollOffsetRef.current += smoothedVelocity * 0.5;
      time += 0.008;

      const rowHeight = h / ROWS.length;

      ROWS.forEach((row, rowIndex) => {
        const baseY = row.yOffset * rowHeight + rowHeight / 2;
        const fontSize = Math.min(rowHeight * 0.5, w * 0.055);

        ctx.font = `700 ${fontSize}px "Space Grotesk", "Helvetica Neue", sans-serif`;
        ctx.textBaseline = 'middle';

        const textWidth = ctx.measureText(row.text).width;
        const spacing = textWidth + 120;
        const cycleOffset = ((scrollOffsetRef.current * row.speed * 0.5) % spacing + spacing) % spacing;

        const repeatCount = Math.ceil(w / spacing) + 3;

        for (let i = -1; i < repeatCount; i++) {
          const xBase = i * spacing - cycleOffset;

          const chars = row.text.split('');
          let charX = xBase;

          chars.forEach((char) => {
            const charW = ctx.measureText(char).width;
            const centerX = charX + charW / 2;

            // Wave distortion
            const wave1 = Math.sin(centerX * 0.003 + time * 2 + rowIndex * 0.8) * 12;
            const wave2 = Math.sin(centerX * 0.007 + time * 1.5 + rowIndex * 1.2) * 6;
            const waveY = wave1 + wave2;

            // Mouse interaction
            const dx = centerX - mouseRef.current.x;
            const dy = baseY - mouseRef.current.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const mouseRadius = 120;
            let mouseEffect = 0;
            let isHovered = false;

            if (dist < mouseRadius) {
              mouseEffect = (1 - dist / mouseRadius) * 25;
              isHovered = true;
            }

            const finalY = baseY + waveY - mouseEffect;

            // 3D bulge effect near mouse
            const bulge = isHovered ? 1 + (1 - dist / mouseRadius) * 0.4 : 1;

            ctx.save();
            ctx.translate(centerX, finalY);
            ctx.scale(bulge, bulge);
            ctx.translate(-centerX, -finalY);

            // Opacity based on wave
            const opacity = 0.4 + Math.abs(Math.sin(centerX * 0.003 + time + rowIndex)) * 0.5;

            if (isHovered) {
              // Invert color on hover
              ctx.fillStyle = '#05050A';
              const bgRadius = charW * 0.7 + (1 - dist / mouseRadius) * 15;
              ctx.beginPath();
              ctx.roundRect(centerX - bgRadius, finalY - fontSize * 0.5, bgRadius * 2, fontSize, 4);
              ctx.fill();
              ctx.fillStyle = row.color;
            } else {
              ctx.fillStyle = hexToRgba(row.color, opacity);
            }

            ctx.fillText(char, charX, finalY);
            ctx.restore();

            charX += charW + fontSize * 0.05;
          });
        }
      });

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [smoothedVelocity]);

  return (
    <section
      ref={sectionRef}
      id="capabilities"
      style={{
        position: 'relative',
        width: '100%',
        height: '80vh',
        minHeight: '500px',
        background: '#0A0A18',
        overflow: 'hidden',
        margin: '20vh 0',
      }}
    >
      {/* Background gradient */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'radial-gradient(ellipse at 50% 50%, rgba(10,10,30,1) 0%, #0A0A18 100%)',
        }}
      />

      {/* Canvas */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <canvas
          ref={canvasRef}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
        />
      </div>

      {/* Section label */}
      <div
        style={{
          position: 'absolute',
          top: '40px',
          left: '50%',
          transform: 'translateX(-50%)',
          textAlign: 'center',
          zIndex: 2,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
          }}
        >
          Core Capabilities
        </p>
      </div>
    </section>
  );
}
