import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface Partner {
  id: number;
  name: string;
  enName: string;
  description: string;
  createdAt: string;
}

function loadPartners(): Partner[] {
  try {
    const raw = localStorage.getItem("shuokin_partners");
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [];
}

const DEFAULT_PARTNERS: Partner[] = [
  { id: 1, name: "优势资本", enName: "ADVANTAGE CAPITAL", description: "中国领先的私募股权投资基金，专注于成长期企业股权投资。", createdAt: "2024-01-01" },
  { id: 2, name: "红杉资本", enName: "SEQUOIA CAPITAL", description: "全球顶级风险投资机构，投资了众多科技创新企业。", createdAt: "2024-01-01" },
  { id: 3, name: "高盛资本", enName: "GOLDMAN SACHS", description: "全球领先的投资银行与金融服务机构，提供全方位资本市场服务。", createdAt: "2024-01-01" },
  { id: 4, name: "IDG资本", enName: "IDG CAPITAL", description: "中国最早的风险投资机构之一，深耕科技与消费领域。", createdAt: "2024-01-01" },
  { id: 5, name: "深创投", enName: "SCGC", description: "中国本土最大的创投机构之一，专注于高新技术领域投资。", createdAt: "2024-01-01" },
  { id: 6, name: "中金资本", enName: "CICC CAPITAL", description: "中国国际金融股份有限公司旗下私募股权投资平台。", createdAt: "2024-01-01" },
];

export default function PartnersSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [partners, setPartners] = useState<Partner[]>(DEFAULT_PARTNERS);

  useEffect(() => {
    const stored = loadPartners();
    if (stored.length > 0) setPartners(stored);

    const handleDataChange = () => {
      const updated = loadPartners();
      if (updated.length > 0) setPartners(updated);
    };
    window.addEventListener("shuokin-data-changed", handleDataChange);
    window.addEventListener("storage", handleDataChange);

    if (!sectionRef.current) return;
    gsap.fromTo(
      sectionRef.current.querySelector('.section-label'),
      { opacity: 0, y: 20 },
      {
        opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
      }
    );
    gsap.fromTo(
      sectionRef.current.querySelectorAll('.partner-card'),
      { opacity: 0, y: 30 },
      {
        opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power3.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 70%' },
      }
    );

    return () => {
      window.removeEventListener("shuokin-data-changed", handleDataChange);
      window.removeEventListener("storage", handleDataChange);
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      style={{
        position: 'relative', width: '100%', padding: '15vh 0', background: '#05050A', margin: '10vh 0',
      }}
    >
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 40px' }}>
        <div className="section-label" style={{ textAlign: 'center', marginBottom: '60px', opacity: 0 }}>
          <p className="font-en" style={{ fontSize: '11px', fontWeight: 500, color: '#8A8A9A', letterSpacing: '0.3em', textTransform: 'uppercase', marginBottom: '16px' }}>
            Strategic Partners
          </p>
          <h2 className="font-display" style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 900, color: '#E8E4E0', letterSpacing: '-0.02em', marginBottom: '12px' }}>
            合作伙伴
          </h2>
          <p className="font-ui" style={{ fontSize: '14px', color: '#8A8A9A', maxWidth: '500px', margin: '0 auto', lineHeight: 1.8 }}>
            携手全球顶级投资机构，为企业提供最优质的资本服务
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
          {partners.map((p, i) => (
            <div key={i} className="partner-card glass-card" style={{
              padding: '32px 28px', display: 'flex', flexDirection: 'column', gap: '12px', opacity: 0,
              transition: 'all 0.3s ease',
            }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'rgba(232,228,224,0.2)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'rgba(232,228,224,0.08)'; e.currentTarget.style.transform = 'translateY(0)'; }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h4 className="font-display" style={{ fontSize: '20px', fontWeight: 700, color: '#E8E4E0', letterSpacing: '-0.02em' }}>{p.name}</h4>
                <div style={{ width: '32px', height: '32px', borderRadius: '50%', border: '1px solid rgba(232,228,224,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span className="font-en" style={{ fontSize: '10px', color: '#8A8A9A', fontWeight: 700 }}>{p.enName.charAt(0)}</span>
                </div>
              </div>
              <span className="font-en" style={{ fontSize: '9px', fontWeight: 500, color: '#8A8A9A', letterSpacing: '0.15em' }}>{p.enName}</span>
              <p className="font-ui" style={{ fontSize: '13px', color: '#8A8A9A', lineHeight: 1.7 }}>{p.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
