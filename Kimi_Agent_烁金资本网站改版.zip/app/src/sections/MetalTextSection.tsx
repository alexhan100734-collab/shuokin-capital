import { useEffect, useRef, useState } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { Environment } from '@react-three/drei';
import * as THREE from 'three';
import gsap from 'gsap';

function createTextTexture(letter: string, fontSize = 256): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = fontSize;
  canvas.height = fontSize;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, fontSize, fontSize);
  ctx.fillStyle = '#000000';
  ctx.font = `900 ${fontSize * 0.75}px "Space Grotesk", "Helvetica Neue", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(letter, fontSize / 2, fontSize / 2);
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

function LetterMesh({ letter, index, total }: { letter: string; index: number; total: number }) {
  const matRef = useRef<THREE.MeshStandardMaterial>(null);

  useEffect(() => {
    if (matRef.current) {
      matRef.current.map = createTextTexture(letter);
      matRef.current.needsUpdate = true;
    }
  }, [letter]);

  const spacing = 1.6;
  const offset = (index - (total - 1) / 2) * spacing;

  return (
    <group position={[offset, 0, 0]}>
      <mesh castShadow>
        <boxGeometry args={[1.2, 1.2, 0.3, 20, 20, 4]} />
        <meshStandardMaterial
          ref={matRef}
          metalness={0.8}
          roughness={0.4}
          color="#C0A060"
        />
      </mesh>
    </group>
  );
}

function MetalTextScene() {
  const groupLookAtRef = useRef<THREE.Group>(null);
  const groupExtrudeRef = useRef<THREE.Group>(null);
  const [_phase, setPhase] = useState<'intro' | 'flash' | 'exit' | 'done'>('intro');
  const { scene } = useThree();

  const letters = ['S', 'H', 'U', 'O', 'K', 'I', 'N'];

  useEffect(() => {
    if (!groupLookAtRef.current || !groupExtrudeRef.current) return;

    const gLook = groupLookAtRef.current;
    const gExt = groupExtrudeRef.current;

    gLook.position.set(0, 0, -50);
    gExt.scale.set(1, 1.2, 1);

    const tl = gsap.timeline({ delay: 0.2 });

    tl.to(gLook.position, {
      z: 3,
      duration: 2.5,
      ease: 'power2.out',
    })
      .to(
        gExt.scale,
        {
          y: 1,
          duration: 2.5,
          ease: 'power3.inOut',
        },
        '<'
      )
      .fromTo(
        scene,
        { backgroundIntensity: 7 },
        { backgroundIntensity: 0, duration: 1.5, ease: 'power2.out' },
        '-=0.5'
      )
      .to(
        gExt.position,
        {
          x: (index: number) => (index < 3 ? -120 : 120),
          y: (index: number) => (index % 2 === 0 ? -80 : 80),
          duration: 1.5,
          ease: 'power3.in',
          stagger: 0.05,
          onComplete: () => setPhase('done'),
        },
        '+=0.3'
      );

    return () => {
      tl.kill();
    };
  }, [scene]);

  return (
    <>
      <Environment preset="city" />
      <ambientLight intensity={0.2} />
      <directionalLight position={[5, 5, 5]} intensity={0.5} />
      <group ref={groupLookAtRef}>
        <group ref={groupExtrudeRef}>
          {letters.map((letter, i) => (
            <LetterMesh key={letter + i} letter={letter} index={i} total={letters.length} />
          ))}
        </group>
      </group>
    </>
  );
}

export default function MetalTextSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [showPhilosophy, setShowPhilosophy] = useState(false);
  const [showCanvas, setShowCanvas] = useState(true);
  const philosophyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowPhilosophy(true);
      setShowCanvas(false);
    }, 6500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (showPhilosophy && philosophyRef.current) {
      gsap.fromTo(
        philosophyRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1.5, ease: 'power3.out' }
      );
    }
  }, [showPhilosophy]);

  return (
    <section
      ref={sectionRef}
      id="philosophy"
      style={{
        position: 'relative',
        width: '100%',
        height: '100vh',
        background: '#05050A',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        margin: '20vh 0',
      }}
    >
      {showCanvas && (
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
        >
          <Canvas
            camera={{ position: [0, 0, 8], fov: 50 }}
            style={{ width: '100%', height: '100%' }}
            gl={{ antialias: true, alpha: false }}
            onCreated={({ scene }) => {
              scene.background = new THREE.Color('#05050A');
            }}
          >
            <MetalTextScene />
          </Canvas>
        </div>
      )}

      <div
        ref={philosophyRef}
        style={{
          position: 'relative',
          zIndex: 10,
          textAlign: 'center',
          opacity: 0,
          padding: '0 40px',
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: 'clamp(10px, 1vw, 14px)',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            marginBottom: '24px',
            textTransform: 'uppercase',
          }}
        >
          Our Philosophy
        </p>
        <h2
          className="font-display"
          style={{
            fontSize: 'clamp(24px, 4vw, 48px)',
            fontWeight: 900,
            color: '#E8E4E0',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            maxWidth: '800px',
            margin: '0 auto',
            textShadow: '0 0 60px rgba(232,228,224,0.1)',
          }}
        >
          专注中小企业并购，赋能产业未来
        </h2>
      </div>
    </section>
  );
}
