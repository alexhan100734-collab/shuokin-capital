import { useRef, useMemo, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/* ---------- Particle Ring ---------- */
function ParticleRing() {
  const pointsRef = useRef<THREE.Points>(null);
  const count = 4000;

  const [positions, velocities] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const vel = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = 3 + Math.random() * 4;
      const height = (Math.random() - 0.5) * 1.5;
      const thickness = (Math.random() - 0.5) * 0.6;

      pos[i * 3] = Math.cos(angle) * radius + thickness;
      pos[i * 3 + 1] = Math.sin(angle) * radius + thickness;
      pos[i * 3 + 2] = height;

      vel[i] = 0.05 + Math.random() * 0.15;
    }

    return [pos, vel];
  }, []);

  useFrame(({ clock }) => {
    if (!pointsRef.current) return;
    const t = clock.getElapsedTime();
    pointsRef.current.rotation.z = t * 0.02;

    const geo = pointsRef.current.geometry as THREE.BufferGeometry;
    const posAttr = geo.attributes.position as THREE.BufferAttribute;
    const arr = posAttr.array as Float32Array;

    for (let i = 0; i < count; i++) {
      const angle = Math.atan2(arr[i * 3 + 1], arr[i * 3]) + velocities[i] * 0.001;
      const r = Math.sqrt(arr[i * 3] * arr[i * 3] + arr[i * 3 + 1] * arr[i * 3 + 1]);
      arr[i * 3] = Math.cos(angle) * r;
      arr[i * 3 + 1] = Math.sin(angle) * r;
    }

    posAttr.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.025}
        color="#AADDFF"
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  );
}

/* ---------- Inner Ring Glow ---------- */
function RingGlow() {
  const meshRef = useRef<THREE.Mesh>(null);

  const shader = useMemo(
    () => ({
      uniforms: {
        uTime: { value: 0 },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        varying vec2 vUv;

        void main() {
          vec2 center = vec2(0.5, 0.5);
          float dist = distance(vUv, center);
          float ring = smoothstep(0.52, 0.45, dist) * smoothstep(0.35, 0.48, dist);

          vec3 color1 = vec3(0.15, 0.10, 0.35);
          vec3 color2 = vec3(0.4, 0.2, 0.5);
          vec3 color3 = vec3(0.6, 0.8, 1.0);

          float t = uTime * 0.3;
          vec3 color = mix(color1, color2, sin(t) * 0.5 + 0.5);
          color = mix(color, color3, ring * 0.5);

          float alpha = ring * 0.4 + smoothstep(0.7, 0.2, dist) * 0.06;
          gl_FragColor = vec4(color, alpha);
        }
      `,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
    []
  );

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const mat = meshRef.current.material as THREE.ShaderMaterial;
    if (mat.uniforms) {
      mat.uniforms.uTime.value = clock.getElapsedTime();
    }
  });

  return (
    <mesh ref={meshRef} rotation={[0, 0, 0]}>
      <planeGeometry args={[18, 18]} />
      <shaderMaterial {...shader} />
    </mesh>
  );
}

/* ---------- Secondary Particles ---------- */
function StarParticles() {
  const pointsRef = useRef<THREE.Points>(null);
  const count = 800;

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 8 + Math.random() * 8;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi) * 0.3;
    }
    return pos;
  }, []);

  useFrame(({ clock }) => {
    if (!pointsRef.current) return;
    const t = clock.getElapsedTime();
    const mat = pointsRef.current.material as THREE.PointsMaterial;
    mat.opacity = 0.3 + Math.sin(t * 0.5) * 0.2;
    pointsRef.current.rotation.y = t * 0.005;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.015}
        color="#AADDFF"
        transparent
        opacity={0.4}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  );
}

function FooterScene() {
  return (
    <>
      <ParticleRing />
      <RingGlow />
      <StarParticles />
    </>
  );
}

export default function FooterSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!contentRef.current) return;

    const tl = gsap.fromTo(
      contentRef.current,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      }
    );

    return () => {
      if (tl.scrollTrigger) tl.scrollTrigger.kill();
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="contact"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        background: '#05050A',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Atmosphere Ring Canvas */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          opacity: 0.6,
        }}
      >
        <Canvas
          camera={{ position: [0, 0, 8], fov: 60 }}
          style={{ width: '100%', height: '100%' }}
          gl={{ antialias: true, alpha: true }}
        >
          <FooterScene />
        </Canvas>
      </div>

      {/* Radial vignette */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'radial-gradient(ellipse at 50% 50%, transparent 30%, rgba(5,5,10,0.8) 70%)',
          pointerEvents: 'none',
          zIndex: 2,
        }}
      />

      {/* Content */}
      <div
        ref={contentRef}
        style={{
          position: 'relative',
          zIndex: 10,
          textAlign: 'center',
          maxWidth: '600px',
          padding: '0 40px',
          opacity: 0,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
            marginBottom: '32px',
          }}
        >
          Get In Touch
        </p>
        <h2
          className="font-display"
          style={{
            fontSize: 'clamp(24px, 4vw, 42px)',
            fontWeight: 900,
            color: '#E8E4E0',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            marginBottom: '20px',
          }}
        >
          联系我们
        </h2>
        <p
          className="font-ui"
          style={{
            fontSize: '16px',
            color: '#8A8A9A',
            letterSpacing: '0.05em',
            marginBottom: '40px',
          }}
        >
          开启并购新纪元
        </p>

        {/* Contact form */}
        <form
          onSubmit={(e) => e.preventDefault()}
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '16px',
            alignItems: 'center',
          }}
        >
          <input
            type="email"
            placeholder="您的邮箱地址"
            className="font-ui"
            style={{
              width: '100%',
              maxWidth: '400px',
              padding: '14px 20px',
              background: 'transparent',
              border: '1px solid rgba(232,228,224,0.15)',
              borderRadius: '2px',
              color: '#E8E4E0',
              fontSize: '14px',
              letterSpacing: '0.05em',
              outline: 'none',
              transition: 'border-color 0.3s ease',
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = 'rgba(232,228,224,0.4)';
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = 'rgba(232,228,224,0.15)';
            }}
          />
          <button
            type="submit"
            className="font-ui"
            style={{
              padding: '14px 40px',
              background: 'transparent',
              border: '1px solid rgba(232,228,224,0.2)',
              borderRadius: '2px',
              color: '#E8E4E0',
              fontSize: '13px',
              fontWeight: 500,
              letterSpacing: '0.1em',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(232,228,224,0.08)';
              e.currentTarget.style.borderColor = 'rgba(232,228,224,0.5)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.borderColor = 'rgba(232,228,224,0.2)';
            }}
          >
            索取商业计划书
          </button>
        </form>

        {/* Footer info */}
        <div
          style={{
            marginTop: '80px',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
          }}
        >
          <p
            className="font-en"
            style={{
              fontSize: '12px',
              fontWeight: 500,
              color: '#8A8A9A',
              letterSpacing: '0.15em',
            }}
          >
            SHUOKIN CAPITAL
          </p>
          <p
            className="font-ui"
            style={{
              fontSize: '11px',
              color: '#8A8A9A',
              letterSpacing: '0.05em',
            }}
          >
            深圳 · 上海 · 香港
          </p>
          <p
            style={{
              fontSize: '10px',
              color: 'rgba(138,138,154,0.5)',
              marginTop: '8px',
            }}
          >
            &copy; 2024 SHUOKIN Capital. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}
