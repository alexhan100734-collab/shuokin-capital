import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const PILLARS = [
  {
    id: 'mergers',
    title: '并购',
    en: 'M&A',
    desc: '专注中国中小企业并购交易，提供从战略筛选、尽职调查到交割整合的全流程顾问服务。',
    detail: '涵盖产业并购、资产收购、跨境并购等多种交易类型，累计完成并购交易86笔。',
    color: '#C0392B',
    route: '/mergers',
  },
  {
    id: 'financing',
    title: '融资',
    en: 'FINANCING',
    desc: '连接优质资本与成长企业，提供股权融资、债权融资、项目融资等多元化资金解决方案。',
    detail: '与红杉资本、高盛资本等顶级机构深度合作，帮助企业高效完成融资目标。',
    color: '#F4D03F',
    route: '/financing',
  },
  {
    id: 'commercial',
    title: '融商',
    en: 'COMMERCIAL',
    desc: '打通产业资源网络，促成企业间战略合作、渠道共建与商业生态协同发展。',
    detail: '依托广泛的产业合作伙伴网络，为企业提供精准的商业资源对接与合作撮合。',
    color: '#1ABC9C',
    route: '/commercial',
  },
];

export default function CoreBusinessSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!cardsRef.current) return;
    const cards = cardsRef.current.querySelectorAll('.biz-card');

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 70%',
        toggleActions: 'play none none reverse',
      },
    });

    const labelEl = sectionRef.current?.querySelector('.section-label');
    if (!labelEl) return;

    tl.fromTo(
      labelEl,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }
    ).fromTo(
      cards,
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.8, stagger: 0.15, ease: 'power3.out' },
      '-=0.4'
    );

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="capabilities"
      style={{
        position: 'relative',
        width: '100%',
        padding: '15vh 0',
        background: '#05050A',
        margin: '10vh 0',
      }}
    >
      {/* Section label */}
      <div
        className="section-label"
        style={{
          textAlign: 'center',
          marginBottom: '60px',
          opacity: 0,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
            marginBottom: '16px',
          }}
        >
          Core Business
        </p>
        <h2
          className="font-display"
          style={{
            fontSize: 'clamp(28px, 4vw, 44px)',
            fontWeight: 900,
            color: '#E8E4E0',
            letterSpacing: '-0.02em',
          }}
        >
          核心业务
        </h2>
      </div>

      {/* Three pillars */}
      <div
        ref={cardsRef}
        style={{
          maxWidth: '1100px',
          margin: '0 auto',
          padding: '0 40px',
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '24px',
        }}
      >
        {PILLARS.map((p) => (
          <div
            key={p.id}
            className="biz-card glass-card"
            onClick={() => navigate(p.route)}
            style={{
              padding: '40px 32px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
              cursor: 'pointer',
              opacity: 0,
              transition: 'all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
              position: 'relative',
              overflow: 'hidden',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = `${p.color}40`;
              e.currentTarget.style.transform = 'translateY(-4px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'rgba(232,228,224,0.08)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            {/* Accent line */}
            <div
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '2px',
                background: `linear-gradient(to right, transparent, ${p.color}, transparent)`,
                opacity: 0.6,
              }}
            />

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3
                className="font-display"
                style={{
                  fontSize: '28px',
                  fontWeight: 900,
                  color: '#E8E4E0',
                  letterSpacing: '-0.02em',
                }}
              >
                {p.title}
              </h3>
              <span
                className="font-en"
                style={{
                  fontSize: '11px',
                  fontWeight: 500,
                  color: p.color,
                  letterSpacing: '0.15em',
                }}
              >
                {p.en}
              </span>
            </div>

            <p
              className="font-ui"
              style={{
                fontSize: '14px',
                color: '#8A8A9A',
                lineHeight: 1.8,
              }}
            >
              {p.desc}
            </p>

            <p
              className="font-ui"
              style={{
                fontSize: '12px',
                color: 'rgba(138,138,154,0.5)',
                lineHeight: 1.8,
              }}
            >
              {p.detail}
            </p>

            <div
              style={{
                marginTop: '8px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <span
                className="font-en"
                style={{
                  fontSize: '11px',
                  fontWeight: 500,
                  color: p.color,
                  letterSpacing: '0.1em',
                }}
              >
                了解更多
              </span>
              <span style={{ color: p.color, fontSize: '14px' }}>→</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
