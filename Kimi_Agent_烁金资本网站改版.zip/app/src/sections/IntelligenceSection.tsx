import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const CATEGORIES = [
  {
    id: 'medical',
    name: '医疗',
    en: 'MEDICAL',
    desc: '创新药、医疗器械、精准医疗、生物制药等细分赛道的并购与融资机会。',
    count: 12,
    projects: [
      { name: '某创新药企业Pre-IPO融资', value: '5亿元', status: '进行中' },
      { name: '医疗器械企业跨境并购', value: '8000万美元', status: '已完成' },
      { name: '精准医疗平台A轮融资', value: '1.2亿元', status: '进行中' },
      { name: '生物制药企业产业整合', value: '3亿元', status: '已完成' },
    ],
  },
  {
    id: 'consumption',
    name: '消费',
    en: 'CONSUMPTION',
    desc: '新消费品牌、零售连锁、食品饮料、消费科技等领域的投资并购动态。',
    count: 8,
    projects: [
      { name: '新茶饮品牌B轮融资', value: '2亿元', status: '已完成' },
      { name: '食品企业品牌收购', value: '1.5亿元', status: '进行中' },
      { name: '消费科技企业战略融资', value: '8000万元', status: '已完成' },
      { name: '零售连锁渠道整合', value: '2.5亿元', status: '进行中' },
    ],
  },
  {
    id: 'tech',
    name: '科技',
    en: 'TECHNOLOGY',
    desc: '半导体、人工智能、新一代信息技术、硬科技等前沿领域的资本运作。',
    count: 15,
    projects: [
      { name: 'AI芯片企业C轮融资', value: '8亿元', status: '进行中' },
      { name: '半导体封测企业收购', value: '4亿元', status: '已完成' },
      { name: '工业软件企业A轮融资', value: '1.5亿元', status: '已完成' },
      { name: '智能硬件企业战略并购', value: '2亿元', status: '进行中' },
    ],
  },
  {
    id: 'energy',
    name: '能源',
    en: 'ENERGY',
    desc: '新能源、储能、光伏、氢能等绿色能源赛道的产业整合与资本对接。',
    count: 10,
    projects: [
      { name: '储能企业B轮融资', value: '6亿元', status: '已完成' },
      { name: '光伏组件企业并购', value: '3.5亿元', status: '进行中' },
      { name: '氢能技术企业A轮融资', value: '2亿元', status: '进行中' },
      { name: '新能源电站资产收购', value: '10亿元', status: '已完成' },
    ],
  },
  {
    id: 'manufacturing',
    name: '制造',
    en: 'MANUFACTURING',
    desc: '先进制造、高端装备、新材料、智能制造等传统产业升级并购机会。',
    count: 9,
    projects: [
      { name: '精密制造企业战略并购', value: '2.8亿元', status: '已完成' },
      { name: '新材料企业A轮融资', value: '1.8亿元', status: '进行中' },
      { name: '智能装备企业收购', value: '4亿元', status: '已完成' },
      { name: '汽车零部件企业产业整合', value: '3亿元', status: '进行中' },
    ],
  },
  {
    id: 'finance',
    name: '金融',
    en: 'FINANCE',
    desc: '金融科技、供应链金融、财富管理、保险科技等金融服务领域的资本运作。',
    count: 6,
    projects: [
      { name: '金融科技企业B轮融资', value: '3亿元', status: '已完成' },
      { name: '供应链金融平台收购', value: '1.2亿元', status: '进行中' },
      { name: '保险科技企业战略融资', value: '2亿元', status: '已完成' },
    ],
  },
];

export default function IntelligenceSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeCat, setActiveCat] = useState<string | null>(null);

  useEffect(() => {
    if (!sectionRef.current) return;

    gsap.fromTo(
      sectionRef.current.querySelector('.section-label'),
      { opacity: 0, y: 20 },
      {
        opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
      }
    );

    gsap.fromTo(
      sectionRef.current.querySelectorAll('.cat-card'),
      { opacity: 0, y: 30 },
      {
        opacity: 1, y: 0, duration: 0.6, stagger: 0.08, ease: 'power3.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 70%' },
      }
    );
  }, []);

  const currentCat = CATEGORIES.find((c) => c.id === activeCat);

  return (
    <section
      ref={sectionRef}
      id="intelligence"
      style={{
        position: 'relative',
        width: '100%',
        padding: '15vh 0',
        background: '#05050A',
        margin: '10vh 0',
      }}
    >
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 40px' }}>
        {/* Section header */}
        <div
          className="section-label"
          style={{ textAlign: 'center', marginBottom: '60px', opacity: 0 }}
        >
          <p
            className="font-en"
            style={{
              fontSize: '11px',
              fontWeight: 500,
              color: '#8A8A9A',
              letterSpacing: '0.3em',
              textTransform: 'uppercase',
              marginBottom: '16px',
            }}
          >
            Enterprise Intelligence
          </p>
          <h2
            className="font-display"
            style={{
              fontSize: 'clamp(28px, 4vw, 44px)',
              fontWeight: 900,
              color: '#E8E4E0',
              letterSpacing: '-0.02em',
              marginBottom: '12px',
            }}
          >
            企业智库
          </h2>
          <p
            className="font-ui"
            style={{
              fontSize: '14px',
              color: '#8A8A9A',
              maxWidth: '500px',
              margin: '0 auto',
              lineHeight: 1.8,
            }}
          >
            按行业分类的并购与投融资项目库
          </p>
        </div>

        {/* Category grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '16px',
            marginBottom: activeCat ? '40px' : '0',
          }}
        >
          {CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              className="cat-card"
              onClick={() => setActiveCat(activeCat === cat.id ? null : cat.id)}
              style={{
                padding: '28px 24px',
                borderRadius: '4px',
                border: `1px solid ${activeCat === cat.id ? 'rgba(244,208,63,0.3)' : 'rgba(232,228,224,0.08)'}`,
                background: activeCat === cat.id ? 'rgba(244,208,63,0.05)' : 'rgba(10,10,18,0.4)',
                cursor: 'pointer',
                opacity: 0,
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                if (activeCat !== cat.id) {
                  e.currentTarget.style.borderColor = 'rgba(232,228,224,0.15)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeCat !== cat.id) {
                  e.currentTarget.style.borderColor = 'rgba(232,228,224,0.08)';
                }
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                <div>
                  <h4
                    className="font-display"
                    style={{
                      fontSize: '20px',
                      fontWeight: 700,
                      color: '#E8E4E0',
                      letterSpacing: '-0.02em',
                      marginBottom: '4px',
                    }}
                  >
                    {cat.name}
                  </h4>
                  <span
                    className="font-en"
                    style={{
                      fontSize: '10px',
                      fontWeight: 500,
                      color: '#8A8A9A',
                      letterSpacing: '0.15em',
                    }}
                  >
                    {cat.en}
                  </span>
                </div>
                <span
                  className="font-en"
                  style={{
                    fontSize: '20px',
                    fontWeight: 700,
                    color: '#F4D03F',
                  }}
                >
                  {cat.count}
                </span>
              </div>
              <p
                className="font-ui"
                style={{
                  fontSize: '12px',
                  color: '#8A8A9A',
                  lineHeight: 1.7,
                }}
              >
                {cat.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Expanded project list */}
        {currentCat && (
          <div
            style={{
              marginTop: '20px',
              padding: '32px',
              borderRadius: '4px',
              border: '1px solid rgba(244,208,63,0.15)',
              background: 'rgba(10,10,18,0.6)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
              <h4
                className="font-display"
                style={{ fontSize: '18px', fontWeight: 700, color: '#E8E4E0' }}
              >
                {currentCat.name}行业项目
              </h4>
              <span
                className="font-en"
                style={{ fontSize: '11px', color: '#8A8A9A', letterSpacing: '0.1em' }}
              >
                {currentCat.count} 个项目
              </span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {currentCat.projects.map((p, i) => (
                <div
                  key={i}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '2fr 1fr 80px',
                    gap: '20px',
                    padding: '14px 16px',
                    borderRadius: '2px',
                    alignItems: 'center',
                    cursor: 'pointer',
                    transition: 'background 0.2s ease',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(232,228,224,0.03)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <span className="font-ui" style={{ fontSize: '14px', color: '#E8E4E0' }}>
                    {p.name}
                  </span>
                  <span className="font-en" style={{ fontSize: '13px', color: '#F4D03F' }}>
                    {p.value}
                  </span>
                  <span
                    className="font-ui"
                    style={{
                      fontSize: '11px',
                      color: p.status === '已完成' ? '#1ABC9C' : '#F4D03F',
                      textAlign: 'right',
                    }}
                  >
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
