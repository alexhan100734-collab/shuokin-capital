import { useEffect, useRef } from 'react';
import { useLenisVelocity } from '../hooks/useLenisVelocity';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface BitParticle {
  x: number;
  y: number;
  value: number;
  life: number;
  speed: number;
  opacity: number;
}

function createBitField(width: number, height: number, cols: number): BitParticle[] {
  const rows = Math.ceil(height / 20) + 2;
  const bits: BitParticle[] = [];
  const colWidth = width / cols;

  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows; r++) {
      bits.push({
        x: c * colWidth + colWidth / 2,
        y: r * 20,
        value: Math.random() > 0.5 ? 1 : 0,
        life: Math.random() * 10,
        speed: 0.3 + Math.random() * 0.5,
        opacity: 0.1 + Math.random() * 0.4,
      });
    }
  }
  return bits;
}

function DataCanvas({
  color,
  speedMultiplier,
  reverse,
}: {
  color: string;
  speedMultiplier: number;
  reverse: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bitsRef = useRef<BitParticle[]>([]);
  const { smoothedVelocity } = useLenisVelocity();
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) return;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      ctx.scale(dpr, dpr);
      bitsRef.current = createBitField(rect.width, rect.height, 40);
    };

    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) {
        rafRef.current = requestAnimationFrame(draw);
        return;
      }

      const w = rect.width;
      const h = rect.height;

      ctx.clearRect(0, 0, w, h);

      const scrollSpeed = smoothedVelocity * speedMultiplier;
      const direction = reverse ? -1 : 1;

      bitsRef.current.forEach((bit) => {
        // Life cycle: 0-10 loop
        bit.life += 0.02 * bit.speed;
        if (bit.life > 10) {
          bit.life = 0;
          bit.value = Math.random() > 0.5 ? 1 : 0;
        }

        // Death: life > 8
        if (bit.life > 8) return;

        // Rising phase: 0-5
        // Falling phase: 5-8
        let yOffset = 0;
        if (bit.life < 5) {
          yOffset = -bit.life * 3 * direction;
        } else {
          yOffset = (bit.life - 5) * 5 * direction;
        }

        // Scroll deformation
        const stretchY = scrollSpeed * 2;

        const finalY = bit.y + yOffset + stretchY;
        const wrappedY = ((finalY % h) + h) % h;

        const fadeIn = Math.min(bit.life / 1, 1);
        const fadeOut = bit.life > 7 ? (8 - bit.life) / 1 : 1;
        const alpha = bit.opacity * fadeIn * fadeOut;

        ctx.font = '13px "Space Grotesk", monospace';
        ctx.fillStyle = color;
        ctx.globalAlpha = alpha;
        ctx.fillText(String(bit.value), bit.x, wrappedY);
        ctx.globalAlpha = 1;
      });

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [smoothedVelocity, speedMultiplier, color, reverse]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
      }}
    />
  );
}

const DATA_CARDS = [
  {
    label: '管理资产规模',
    value: '¥120亿+',
    sub: '累计管理资产',
  },
  {
    label: '累计交易数量',
    value: '86',
    sub: '完成并购交易',
  },
  {
    label: '重点覆盖赛道',
    value: '5',
    sub: '核心产业领域',
  },
  {
    label: '专业团队',
    value: '45+',
    sub: '并购与投资顾问',
  },
];

export default function DataStreamSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!cardsRef.current) return;
    const cards = cardsRef.current.querySelectorAll('.data-card');

    cards.forEach((card, i) => {
      gsap.fromTo(
        card,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: i * 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="data"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        background: '#05050A',
        overflow: 'hidden',
        margin: '20vh 0',
      }}
    >
      {/* Left red stream */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '50%',
          height: '100%',
          overflow: 'hidden',
        }}
      >
        <DataCanvas color="rgba(192,57,43,0.6)" speedMultiplier={1.2} reverse={false} />
      </div>

      {/* Right cyan stream */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          right: 0,
          width: '50%',
          height: '100%',
          overflow: 'hidden',
        }}
      >
        <DataCanvas color="rgba(26,188,156,0.6)" speedMultiplier={0.8} reverse={true} />
      </div>

      {/* Center divider */}
      <div
        style={{
          position: 'absolute',
          top: '10%',
          left: '50%',
          width: '1px',
          height: '80%',
          background: 'linear-gradient(to bottom, transparent, rgba(232,228,224,0.1), transparent)',
          zIndex: 2,
        }}
      />

      {/* Glassmorphism data cards */}
      <div
        ref={cardsRef}
        style={{
          position: 'relative',
          zIndex: 10,
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '24px',
          maxWidth: '1000px',
          margin: '0 auto',
          padding: '15vh 40px',
        }}
      >
        {DATA_CARDS.map((card, i) => (
          <div
            key={i}
            className="data-card glass-card"
            style={{
              padding: '36px 28px',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px',
              opacity: 0,
            }}
          >
            <p
              className="font-en"
              style={{
                fontSize: '10px',
                fontWeight: 500,
                color: '#8A8A9A',
                letterSpacing: '0.15em',
                textTransform: 'uppercase',
              }}
            >
              {card.label}
            </p>
            <p
              className="font-en"
              style={{
                fontSize: '36px',
                fontWeight: 700,
                color: '#E8E4E0',
                letterSpacing: '-0.02em',
                lineHeight: 1.2,
              }}
            >
              {card.value}
            </p>
            <p
              className="font-ui"
              style={{
                fontSize: '12px',
                color: '#8A8A9A',
                letterSpacing: '0.05em',
              }}
            >
              {card.sub}
            </p>
          </div>
        ))}
      </div>

      {/* Section label */}
      <div
        style={{
          position: 'absolute',
          top: '40px',
          left: '50%',
          transform: 'translateX(-50%)',
          textAlign: 'center',
          zIndex: 10,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
          }}
        >
          The Data Stream
        </p>
      </div>
    </section>
  );
}
