import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface Project {
  id: number;
  name: string;
  type: "并购" | "融资" | "融商";
  industry: string;
  value: string;
  status: "已完成" | "进行中" | "已终止";
  description: string;
  createdAt: string;
}

function loadProjects(): Project[] {
  try {
    const raw = localStorage.getItem("shuokin_projects");
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [];
}

const DEFAULT_PROJECTS: Project[] = [
  { id: 1, name: "某新能源电池企业收购案", type: "并购", industry: "新能源", value: "3.2亿元", status: "已完成", description: "", createdAt: "2024-01-15" },
  { id: 2, name: "AI芯片企业A轮融资", type: "融资", industry: "半导体", value: "2亿元", status: "进行中", description: "", createdAt: "2024-02-20" },
  { id: 3, name: "精密制造产业链整合", type: "并购", industry: "先进制造", value: "1.8亿元", status: "进行中", description: "", createdAt: "2024-03-10" },
  { id: 4, name: "生物医药企业B轮融资", type: "融资", industry: "医疗", value: "3.5亿元", status: "已完成", description: "", createdAt: "2024-01-28" },
  { id: 5, name: "医疗器械跨境收购", type: "并购", industry: "医疗", value: "5000万美元", status: "已完成", description: "", createdAt: "2024-02-05" },
  { id: 6, name: "消费品牌战略合作", type: "融商", industry: "消费", value: "战略合作", status: "进行中", description: "", createdAt: "2024-03-18" },
];

export default function ProjectListSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [projects, setProjects] = useState<Project[]>(DEFAULT_PROJECTS);

  useEffect(() => {
    // Load from localStorage on mount
    const stored = loadProjects();
    if (stored.length > 0) setProjects(stored);

    // Listen for changes from admin panel (same-tab via custom event)
    const handleDataChange = () => {
      const updated = loadProjects();
      if (updated.length > 0) setProjects(updated);
    };
    window.addEventListener("shuokin-data-changed", handleDataChange);
    // Also listen for cross-tab storage changes
    window.addEventListener("storage", handleDataChange);

    if (!sectionRef.current) return;
    gsap.fromTo(
      sectionRef.current.querySelector('.section-label'),
      { opacity: 0, y: 20 },
      {
        opacity: 1, y: 0, duration: 0.8, ease: 'power3.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
      }
    );
    gsap.fromTo(
      sectionRef.current.querySelectorAll('.project-row'),
      { opacity: 0, x: -20 },
      {
        opacity: 1, x: 0, duration: 0.6, stagger: 0.08, ease: 'power3.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 70%' },
      }
    );

    return () => {
      window.removeEventListener("shuokin-data-changed", handleDataChange);
      window.removeEventListener("storage", handleDataChange);
    };
  }, []);

  const typeColor = (type: string) => {
    switch (type) {
      case '并购': return '#C0392B';
      case '融资': return '#F4D03F';
      case '融商': return '#1ABC9C';
      default: return '#8A8A9A';
    }
  };

  return (
    <section
      ref={sectionRef}
      style={{
        position: 'relative', width: '100%', padding: '10vh 0', background: '#05050A',
      }}
    >
      <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '0 40px' }}>
        <div className="section-label" style={{ marginBottom: '40px', opacity: 0 }}>
          <p className="font-en" style={{ fontSize: '11px', fontWeight: 500, color: '#8A8A9A', letterSpacing: '0.3em', textTransform: 'uppercase', marginBottom: '12px' }}>
            Featured Projects
          </p>
          <h2 className="font-display" style={{ fontSize: 'clamp(24px, 3vw, 36px)', fontWeight: 900, color: '#E8E4E0', letterSpacing: '-0.02em' }}>
            推荐项目
          </h2>
        </div>

        {/* Table header */}
        <div style={{
          display: 'grid', gridTemplateColumns: '2fr 80px 100px 100px 80px',
          gap: '12px', padding: '12px 20px', borderBottom: '1px solid rgba(232,228,224,0.1)', marginBottom: '4px',
        }}>
          {['项目名称', '类型', '行业', '规模', '状态'].map((h) => (
            <span key={h} className="font-en" style={{ fontSize: '10px', fontWeight: 500, color: '#8A8A9A', letterSpacing: '0.15em', textTransform: 'uppercase' }}>{h}</span>
          ))}
        </div>

        {/* Rows */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {projects.map((p) => (
            <div key={p.id} className="project-row" style={{
              display: 'grid', gridTemplateColumns: '2fr 80px 100px 100px 80px',
              gap: '12px', padding: '16px 20px', alignItems: 'center', borderRadius: '4px',
              cursor: 'pointer', opacity: 0, transition: 'background 0.3s ease',
            }}
              onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(232,228,224,0.03)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}
            >
              <span className="font-ui" style={{ fontSize: '14px', color: '#E8E4E0', fontWeight: 500 }}>{p.name}</span>
              <span className="font-ui" style={{ fontSize: '12px', color: typeColor(p.type), fontWeight: 500 }}>{p.type}</span>
              <span className="font-ui" style={{ fontSize: '12px', color: '#8A8A9A' }}>{p.industry}</span>
              <span className="font-en" style={{ fontSize: '13px', color: '#F4D03F' }}>{p.value}</span>
              <span className="font-ui" style={{ fontSize: '11px', color: p.status === '已完成' ? '#1ABC9C' : '#F4D03F' }}>{p.status}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
