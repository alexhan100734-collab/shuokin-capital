import { trpc } from "@/providers/trpc";
import { Link } from "react-router-dom";

const statCard = (label: string, value: string, color: string) => (
  <div className="glass-card" style={{
    padding: "28px",
    display: "flex",
    flexDirection: "column",
    gap: "8px",
  }}>
    <span style={{ fontSize: "11px", color: "#8A8A9A", letterSpacing: "0.1em" }}>{label}</span>
    <span className="font-en" style={{ fontSize: "32px", fontWeight: 700, color }}>{value}</span>
  </div>
);

export default function AdminDashboard() {
  const { data: projects } = trpc.project.list.useQuery();
  const { data: partners } = trpc.partner.list.useQuery();

  const projectCount = projects?.length ?? 0;
  const partnerCount = partners?.length ?? 0;
  const activeProjects = projects?.filter((p) => p.status === "进行中").length ?? 0;
  const completedProjects = projects?.filter((p) => p.status === "已完成").length ?? 0;

  const mergerCount = projects?.filter((p) => p.type === "并购").length ?? 0;
  const financeCount = projects?.filter((p) => p.type === "融资").length ?? 0;
  const commercialCount = projects?.filter((p) => p.type === "融商").length ?? 0;

  return (
    <div>
      <h1 className="font-display" style={{ fontSize: "28px", fontWeight: 900, marginBottom: "32px" }}>
        仪表盘
      </h1>

      {/* Stats grid */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: "16px",
        marginBottom: "40px",
      }}>
        {statCard("项目总数", String(projectCount), "#E8E4E0")}
        {statCard("进行中", String(activeProjects), "#F4D03F")}
        {statCard("已完成", String(completedProjects), "#1ABC9C")}
        {statCard("合作伙伴", String(partnerCount), "#AADDFF")}
      </div>

      {/* Quick links */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
        <div className="glass-card" style={{ padding: "28px" }}>
          <h3 className="font-display" style={{ fontSize: "18px", fontWeight: 700, marginBottom: "12px" }}>
            项目分布
          </h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: "13px", color: "#8A8A9A" }}>并购</span>
              <span className="font-en" style={{ fontSize: "14px", color: "#C0392B", fontWeight: 500 }}>{mergerCount}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: "13px", color: "#8A8A9A" }}>融资</span>
              <span className="font-en" style={{ fontSize: "14px", color: "#F4D03F", fontWeight: 500 }}>{financeCount}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: "13px", color: "#8A8A9A" }}>融商</span>
              <span className="font-en" style={{ fontSize: "14px", color: "#1ABC9C", fontWeight: 500 }}>{commercialCount}</span>
            </div>
          </div>
          <Link
            to="/admin/projects"
            style={{
              display: "inline-block", marginTop: "16px",
              fontSize: "12px", color: "#8A8A9A", textDecoration: "none",
            }}
          >
            管理项目 →
          </Link>
        </div>

        <div className="glass-card" style={{ padding: "28px" }}>
          <h3 className="font-display" style={{ fontSize: "18px", fontWeight: 700, marginBottom: "12px" }}>
            快捷操作
          </h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <Link
              to="/admin/projects"
              style={{
                padding: "10px 16px",
                border: "1px solid rgba(232,228,224,0.15)",
                borderRadius: "4px",
                fontSize: "13px",
                color: "#E8E4E0",
                textDecoration: "none",
                transition: "border-color 0.2s ease",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = "rgba(232,228,224,0.4)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(232,228,224,0.15)"; }}
            >
              + 添加新项目
            </Link>
            <Link
              to="/admin/partners"
              style={{
                padding: "10px 16px",
                border: "1px solid rgba(232,228,224,0.15)",
                borderRadius: "4px",
                fontSize: "13px",
                color: "#E8E4E0",
                textDecoration: "none",
                transition: "border-color 0.2s ease",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = "rgba(232,228,224,0.4)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(232,228,224,0.15)"; }}
            >
              + 添加合作伙伴
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
