import HeroSection from '../sections/HeroSection';
import MetalTextSection from '../sections/MetalTextSection';
import CoreBusinessSection from '../sections/CoreBusinessSection';
import ProjectListSection from '../sections/ProjectListSection';
import IntelligenceSection from '../sections/IntelligenceSection';
import PartnersSection from '../sections/PartnersSection';
import FooterSection from '../sections/FooterSection';

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <MetalTextSection />
      <CoreBusinessSection />
      <ProjectListSection />
      <IntelligenceSection />
      <PartnersSection />
      <FooterSection />
    </>
  );
}
