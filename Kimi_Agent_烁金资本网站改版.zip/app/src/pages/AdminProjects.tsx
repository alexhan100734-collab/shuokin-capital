import { useState } from "react";
import { trpc } from "@/providers/trpc";

const TYPE_COLORS: Record<string, string> = {
  "并购": "#C0392B",
  "融资": "#F4D03F",
  "融商": "#1ABC9C",
};

const STATUS_COLORS: Record<string, string> = {
  "已完成": "#1ABC9C",
  "进行中": "#F4D03F",
  "已终止": "#8A8A9A",
};

export default function AdminProjects() {
  const utils = trpc.useUtils();
  const { data: projects, isLoading } = trpc.project.list.useQuery();
  const createMutation = trpc.project.create.useMutation({
    onSuccess: () => { utils.project.list.invalidate(); setShowForm(false); resetForm(); },
  });
  const updateMutation = trpc.project.update.useMutation({
    onSuccess: () => { utils.project.list.invalidate(); setEditingId(null); resetForm(); },
  });
  const deleteMutation = trpc.project.delete.useMutation({
    onSuccess: () => utils.project.list.invalidate(),
  });

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    name: "", type: "并购" as "并购" | "融资" | "融商",
    industry: "", value: "", status: "进行中" as "已完成" | "进行中" | "已终止",
    description: "",
  });

  const resetForm = () => setForm({ name: "", type: "并购", industry: "", value: "", status: "进行中", description: "" });

  const handleEdit = (p: NonNullable<typeof projects>[0]) => {
    setForm({
      name: p.name, type: p.type,
      industry: p.industry, value: p.value, status: p.status,
      description: p.description ?? "",
    });
    setEditingId(p.id);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "32px" }}>
        <h1 className="font-display" style={{ fontSize: "28px", fontWeight: 900 }}>项目管理</h1>
        <button
          onClick={() => { setShowForm(!showForm); setEditingId(null); resetForm(); }}
          style={{
            padding: "10px 24px", background: "transparent", border: "1px solid rgba(232,228,224,0.2)",
            borderRadius: "4px", color: "#E8E4E0", fontSize: "13px", cursor: "pointer",
          }}
        >
          {showForm ? "取消" : "+ 新增项目"}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card" style={{ padding: "28px", marginBottom: "32px" }}>
          <h3 className="font-display" style={{ fontSize: "18px", marginBottom: "20px" }}>
            {editingId ? "编辑项目" : "新增项目"}
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>项目名称</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                style={inputStyle} required />
            </div>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>交易类型</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as "并购" | "融资" | "融商" })}
                style={inputStyle}>
                <option value="并购">并购</option>
                <option value="融资">融资</option>
                <option value="融商">融商</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>所属行业</label>
              <input value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })}
                style={inputStyle} required />
            </div>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>交易规模</label>
              <input value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })}
                style={inputStyle} required placeholder="如：3.2亿元" />
            </div>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>状态</label>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as "已完成" | "进行中" | "已终止" })}
                style={inputStyle}>
                <option value="进行中">进行中</option>
                <option value="已完成">已完成</option>
                <option value="已终止">已终止</option>
              </select>
            </div>
            <div style={{ gridColumn: "span 2" }}>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>项目描述</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                style={{ ...inputStyle, minHeight: "80px", resize: "vertical" }} />
            </div>
          </div>
          <div style={{ marginTop: "20px", display: "flex", gap: "12px" }}>
            <button type="submit" style={{
              padding: "10px 28px", background: "rgba(232,228,224,0.1)", border: "1px solid rgba(232,228,224,0.3)",
              borderRadius: "4px", color: "#E8E4E0", fontSize: "13px", cursor: "pointer",
            }}>
              {editingId ? "保存修改" : "创建项目"}
            </button>
          </div>
        </form>
      )}

      {/* Table */}
      {isLoading ? (
        <p style={{ color: "#8A8A9A", textAlign: "center", padding: "40px" }}>加载中...</p>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          {/* Header */}
          <div style={{
            display: "grid", gridTemplateColumns: "2fr 80px 100px 100px 80px 100px",
            gap: "12px", padding: "12px 16px", borderBottom: "1px solid rgba(232,228,224,0.1)",
          }}>
            {["项目名称", "类型", "行业", "规模", "状态", "操作"].map((h) => (
              <span key={h} style={{ fontSize: "10px", color: "#8A8A9A", letterSpacing: "0.15em", textTransform: "uppercase" }}>{h}</span>
            ))}
          </div>

          {/* Rows */}
          {projects?.map((p) => (
            <div key={p.id} className="glass-card" style={{
              display: "grid", gridTemplateColumns: "2fr 80px 100px 100px 80px 100px",
              gap: "12px", padding: "14px 16px", alignItems: "center",
            }}>
              <span style={{ fontSize: "14px", color: "#E8E4E0" }}>{p.name}</span>
              <span style={{ fontSize: "12px", color: TYPE_COLORS[p.type], fontWeight: 500 }}>{p.type}</span>
              <span style={{ fontSize: "12px", color: "#8A8A9A" }}>{p.industry}</span>
              <span className="font-en" style={{ fontSize: "13px", color: "#F4D03F" }}>{p.value}</span>
              <span style={{ fontSize: "11px", color: STATUS_COLORS[p.status] }}>{p.status}</span>
              <div style={{ display: "flex", gap: "8px" }}>
                <button onClick={() => handleEdit(p)} style={linkBtn}>编辑</button>
                <button onClick={() => { if (confirm("确定删除？")) deleteMutation.mutate({ id: p.id }); }} style={linkBtn}>删除</button>
              </div>
            </div>
          ))}

          {projects?.length === 0 && (
            <p style={{ color: "#8A8A9A", textAlign: "center", padding: "40px" }}>暂无项目，点击上方按钮添加</p>
          )}
        </div>
      )}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 14px",
  background: "rgba(5,5,10,0.6)",
  border: "1px solid rgba(232,228,224,0.12)",
  borderRadius: "4px",
  color: "#E8E4E0",
  fontSize: "13px",
  outline: "none",
};

const linkBtn: React.CSSProperties = {
  fontSize: "11px",
  color: "#8A8A9A",
  background: "none",
  border: "none",
  cursor: "pointer",
  padding: 0,
  textDecoration: "underline",
};
