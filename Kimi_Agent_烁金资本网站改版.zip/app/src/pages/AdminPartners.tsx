import { useState } from "react";
import { trpc } from "@/providers/trpc";

export default function AdminPartners() {
  const utils = trpc.useUtils();
  const { data: partners, isLoading } = trpc.partner.list.useQuery();
  const createMutation = trpc.partner.create.useMutation({
    onSuccess: () => { utils.partner.list.invalidate(); setShowForm(false); resetForm(); },
  });
  const updateMutation = trpc.partner.update.useMutation({
    onSuccess: () => { utils.partner.list.invalidate(); setEditingId(null); resetForm(); },
  });
  const deleteMutation = trpc.partner.delete.useMutation({
    onSuccess: () => utils.partner.list.invalidate(),
  });

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", enName: "", description: "" });

  const resetForm = () => setForm({ name: "", enName: "", description: "" });

  const handleEdit = (p: NonNullable<typeof partners>[0]) => {
    setForm({ name: p.name, enName: p.enName, description: p.description ?? "" });
    setEditingId(p.id);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "32px" }}>
        <h1 className="font-display" style={{ fontSize: "28px", fontWeight: 900 }}>合作伙伴</h1>
        <button
          onClick={() => { setShowForm(!showForm); setEditingId(null); resetForm(); }}
          style={{
            padding: "10px 24px", background: "transparent", border: "1px solid rgba(232,228,224,0.2)",
            borderRadius: "4px", color: "#E8E4E0", fontSize: "13px", cursor: "pointer",
          }}
        >
          {showForm ? "取消" : "+ 新增伙伴"}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card" style={{ padding: "28px", marginBottom: "32px" }}>
          <h3 className="font-display" style={{ fontSize: "18px", marginBottom: "20px" }}>
            {editingId ? "编辑合作伙伴" : "新增合作伙伴"}
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>中文名称</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                style={inputStyle} required />
            </div>
            <div>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>英文名称</label>
              <input value={form.enName} onChange={(e) => setForm({ ...form, enName: e.target.value })}
                style={inputStyle} required />
            </div>
            <div style={{ gridColumn: "span 2" }}>
              <label style={{ fontSize: "12px", color: "#8A8A9A", display: "block", marginBottom: "6px" }}>描述</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                style={{ ...inputStyle, minHeight: "80px", resize: "vertical" }} />
            </div>
          </div>
          <div style={{ marginTop: "20px" }}>
            <button type="submit" style={{
              padding: "10px 28px", background: "rgba(232,228,224,0.1)", border: "1px solid rgba(232,228,224,0.3)",
              borderRadius: "4px", color: "#E8E4E0", fontSize: "13px", cursor: "pointer",
            }}>
              {editingId ? "保存修改" : "创建"}
            </button>
          </div>
        </form>
      )}

      {/* List */}
      {isLoading ? (
        <p style={{ color: "#8A8A9A", textAlign: "center", padding: "40px" }}>加载中...</p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
          {partners?.map((p) => (
            <div key={p.id} className="glass-card" style={{ padding: "24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
                <div>
                  <h4 className="font-display" style={{ fontSize: "18px", fontWeight: 700, color: "#E8E4E0" }}>
                    {p.name}
                  </h4>
                  <span className="font-en" style={{ fontSize: "10px", color: "#8A8A9A", letterSpacing: "0.15em" }}>
                    {p.enName}
                  </span>
                </div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button onClick={() => handleEdit(p)} style={linkBtn}>编辑</button>
                  <button onClick={() => { if (confirm("确定删除？")) deleteMutation.mutate({ id: p.id }); }} style={linkBtn}>删除</button>
                </div>
              </div>
              <p style={{ fontSize: "13px", color: "#8A8A9A", lineHeight: 1.6 }}>
                {p.description}
              </p>
            </div>
          ))}

          {partners?.length === 0 && (
            <p style={{ color: "#8A8A9A", textAlign: "center", padding: "40px", gridColumn: "span 2" }}>
              暂无合作伙伴，点击上方按钮添加
            </p>
          )}
        </div>
      )}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 14px",
  background: "rgba(5,5,10,0.6)",
  border: "1px solid rgba(232,228,224,0.12)",
  borderRadius: "4px",
  color: "#E8E4E0",
  fontSize: "13px",
  outline: "none",
};

const linkBtn: React.CSSProperties = {
  fontSize: "11px",
  color: "#8A8A9A",
  background: "none",
  border: "none",
  cursor: "pointer",
  padding: 0,
  textDecoration: "underline",
};
