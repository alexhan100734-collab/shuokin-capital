import { useEffect, useRef } from 'react';
import gsap from 'gsap';

const SERVICES = [
  {
    title: '并购战略咨询',
    desc: '为企业提供全面的并购战略规划，包括目标筛选、尽职调查、估值分析及交易结构设计。',
  },
  {
    title: '交易撮合服务',
    desc: '依托广泛的产业资源网络，精准匹配买卖双方，促成高效交易达成。',
  },
  {
    title: '并购后整合',
    desc: '协助企业完成并购后的组织整合、文化融合与业务协同，最大化并购价值。',
  },
  {
    title: '跨境并购顾问',
    desc: '专注中国中小企业海外并购与外资入境并购，提供全程法律、财务、税务一站式顾问服务。',
  },
];

const PROJECTS = [
  { name: '某新能源电池企业收购案', type: '产业并购', value: '3.2亿元', status: '已完成' },
  { name: '精密制造产业链整合', type: '横向并购', value: '1.8亿元', status: '进行中' },
  { name: '医疗器械企业跨境收购', type: '跨境并购', value: '5000万美元', status: '已完成' },
  { name: '半导体封装资产剥离', type: '资产并购', value: '2.1亿元', status: '已完成' },
  { name: '消费品品牌整合收购', type: '品牌并购', value: '8000万元', status: '进行中' },
];

export default function MergersPage() {
  const headerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline();
    tl.fromTo(
      headerRef.current,
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }
    ).fromTo(
      contentRef.current?.children || [],
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, stagger: 0.1, ease: 'power3.out' },
      '-=0.5'
    );
  }, []);

  return (
    <div style={{ minHeight: '100vh', paddingTop: '80px', paddingBottom: '120px' }}>
      {/* Header */}
      <div
        ref={headerRef}
        style={{
          textAlign: 'center',
          padding: '60px 40px 40px',
          opacity: 0,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
            marginBottom: '16px',
          }}
        >
          Core Business
        </p>
        <h1
          className="font-display"
          style={{
            fontSize: 'clamp(32px, 5vw, 56px)',
            fontWeight: 900,
            color: '#E8E4E0',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            marginBottom: '16px',
          }}
        >
          并购服务
        </h1>
        <p
          className="font-ui"
          style={{
            fontSize: '16px',
            color: '#8A8A9A',
            maxWidth: '600px',
            margin: '0 auto',
          }}
        >
          专注中国中小企业并购，提供从战略到交割的全流程服务
        </p>
      </div>

      {/* Services */}
      <div
        ref={contentRef}
        style={{
          maxWidth: '1000px',
          margin: '0 auto',
          padding: '40px',
          display: 'grid',
          gap: '24px',
        }}
      >
        {SERVICES.map((s, i) => (
          <div
            key={i}
            className="glass-card"
            style={{
              padding: '36px',
              display: 'grid',
              gridTemplateColumns: '1fr 2fr',
              gap: '32px',
              alignItems: 'start',
            }}
          >
            <h3
              className="font-display"
              style={{
                fontSize: '20px',
                fontWeight: 700,
                color: '#E8E4E0',
                lineHeight: 1.3,
              }}
            >
              {s.title}
            </h3>
            <p
              className="font-ui"
              style={{
                fontSize: '14px',
                color: '#8A8A9A',
                lineHeight: 1.8,
              }}
            >
              {s.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Project List */}
      <div style={{ maxWidth: '1000px', margin: '60px auto', padding: '0 40px' }}>
        <h2
          className="font-display"
          style={{
            fontSize: '28px',
            fontWeight: 700,
            color: '#E8E4E0',
            marginBottom: '32px',
          }}
        >
          推荐并购项目
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {PROJECTS.map((p, i) => (
            <div
              key={i}
              className="glass-card"
              style={{
                padding: '20px 28px',
                display: 'grid',
                gridTemplateColumns: '2fr 1fr 1fr 80px',
                gap: '20px',
                alignItems: 'center',
                cursor: 'pointer',
                transition: 'border-color 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'rgba(232,228,224,0.2)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(232,228,224,0.08)';
              }}
            >
              <span className="font-ui" style={{ fontSize: '15px', color: '#E8E4E0', fontWeight: 500 }}>
                {p.name}
              </span>
              <span className="font-ui" style={{ fontSize: '13px', color: '#8A8A9A' }}>
                {p.type}
              </span>
              <span className="font-en" style={{ fontSize: '14px', color: '#F4D03F', fontWeight: 500 }}>
                {p.value}
              </span>
              <span
                className="font-ui"
                style={{
                  fontSize: '11px',
                  color: p.status === '已完成' ? '#1ABC9C' : '#F4D03F',
                  textAlign: 'right',
                }}
              >
                {p.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
