import { useEffect, useRef } from 'react';
import gsap from 'gsap';

const SERVICES = [
  {
    title: '股权融资顾问',
    desc: '为企业量身定制股权融资方案，协助对接顶级投资机构，优化估值与条款设计。',
  },
  {
    title: '债权融资服务',
    desc: '提供银行信贷、债券发行、供应链金融等多元化债权融资方案。',
  },
  {
    title: '项目融资咨询',
    desc: '针对大型基础设施、能源、制造等项目，提供结构化融资与风险分担方案。',
  },
  {
    title: '融资路演支持',
    desc: '协助企业准备融资材料、投资人路演及商业计划书，提升融资成功率。',
  },
];

const PROJECTS = [
  { name: 'AI芯片企业A轮融资', type: '股权融资', value: '2亿元', status: '进行中' },
  { name: '生物医药企业B轮', type: '股权融资', value: '3.5亿元', status: '已完成' },
  { name: '新能源装备制造项目', type: '项目融资', value: '5亿元', status: '进行中' },
  { name: '消费品牌Pre-IPO轮', type: '股权融资', value: '1.5亿元', status: '已完成' },
  { name: '智慧物流企业债权融资', type: '债权融资', value: '8000万元', status: '已完成' },
];

export default function FinancingPage() {
  const headerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline();
    tl.fromTo(
      headerRef.current,
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }
    ).fromTo(
      contentRef.current?.children || [],
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, stagger: 0.1, ease: 'power3.out' },
      '-=0.5'
    );
  }, []);

  return (
    <div style={{ minHeight: '100vh', paddingTop: '80px', paddingBottom: '120px' }}>
      <div
        ref={headerRef}
        style={{
          textAlign: 'center',
          padding: '60px 40px 40px',
          opacity: 0,
        }}
      >
        <p
          className="font-en"
          style={{
            fontSize: '11px',
            fontWeight: 500,
            color: '#8A8A9A',
            letterSpacing: '0.3em',
            textTransform: 'uppercase',
            marginBottom: '16px',
          }}
        >
          Core Business
        </p>
        <h1
          className="font-display"
          style={{
            fontSize: 'clamp(32px, 5vw, 56px)',
            fontWeight: 900,
            color: '#E8E4E0',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
            marginBottom: '16px',
          }}
        >
          融资服务
        </h1>
        <p
          className="font-ui"
          style={{
            fontSize: '16px',
            color: '#8A8A9A',
            maxWidth: '600px',
            margin: '0 auto',
          }}
        >
          连接优质资本与成长企业，打造高效融资通道
        </p>
      </div>

      <div
        ref={contentRef}
        style={{
          maxWidth: '1000px',
          margin: '0 auto',
          padding: '40px',
          display: 'grid',
          gap: '24px',
        }}
      >
        {SERVICES.map((s, i) => (
          <div
            key={i}
            className="glass-card"
            style={{
              padding: '36px',
              display: 'grid',
              gridTemplateColumns: '1fr 2fr',
              gap: '32px',
              alignItems: 'start',
            }}
          >
            <h3
              className="font-display"
              style={{
                fontSize: '20px',
                fontWeight: 700,
                color: '#E8E4E0',
                lineHeight: 1.3,
              }}
            >
              {s.title}
            </h3>
            <p
              className="font-ui"
              style={{
                fontSize: '14px',
                color: '#8A8A9A',
                lineHeight: 1.8,
              }}
            >
              {s.desc}
            </p>
          </div>
        ))}
      </div>

      <div style={{ maxWidth: '1000px', margin: '60px auto', padding: '0 40px' }}>
        <h2
          className="font-display"
          style={{
            fontSize: '28px',
            fontWeight: 700,
            color: '#E8E4E0',
            marginBottom: '32px',
          }}
        >
          推荐融资项目
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {PROJECTS.map((p, i) => (
            <div
              key={i}
              className="glass-card"
              style={{
                padding: '20px 28px',
                display: 'grid',
                gridTemplateColumns: '2fr 1fr 1fr 80px',
                gap: '20px',
                alignItems: 'center',
                cursor: 'pointer',
                transition: 'border-color 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'rgba(232,228,224,0.2)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(232,228,224,0.08)';
              }}
            >
              <span className="font-ui" style={{ fontSize: '15px', color: '#E8E4E0', fontWeight: 500 }}>
                {p.name}
              </span>
              <span className="font-ui" style={{ fontSize: '13px', color: '#8A8A9A' }}>
                {p.type}
              </span>
              <span className="font-en" style={{ fontSize: '14px', color: '#F4D03F', fontWeight: 500 }}>
                {p.value}
              </span>
              <span
                className="font-ui"
                style={{
                  fontSize: '11px',
                  color: p.status === '已完成' ? '#1ABC9C' : '#F4D03F',
                  textAlign: 'right',
                }}
              >
                {p.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
