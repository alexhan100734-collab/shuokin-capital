import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { projects } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const projectRouter = createRouter({
  // List all projects
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(projects).orderBy(desc(projects.createdAt));
  }),

  // Get single project
  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db.select().from(projects).where(eq(projects.id, input.id));
      return rows[0] ?? null;
    }),

  // Create project
  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        type: z.enum(["并购", "融资", "融商"]),
        industry: z.string().min(1).max(100),
        value: z.string().min(1).max(100),
        status: z.enum(["已完成", "进行中", "已终止"]).default("进行中"),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(projects).values({
        name: input.name,
        type: input.type,
        industry: input.industry,
        value: input.value,
        status: input.status,
        description: input.description ?? null,
      });
      return { id: Number(result[0].insertId) };
    }),

  // Update project
  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255),
        type: z.enum(["并购", "融资", "融商"]),
        industry: z.string().min(1).max(100),
        value: z.string().min(1).max(100),
        status: z.enum(["已完成", "进行中", "已终止"]),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(projects).set(data).where(eq(projects.id, id));
      return { success: true };
    }),

  // Delete project
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(projects).where(eq(projects.id, input.id));
      return { success: true };
    }),
});
