import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { partners } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const partnerRouter = createRouter({
  // List all partners
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(partners).orderBy(desc(partners.createdAt));
  }),

  // Get single partner
  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db.select().from(partners).where(eq(partners.id, input.id));
      return rows[0] ?? null;
    }),

  // Create partner
  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        enName: z.string().min(1).max(255),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(partners).values({
        name: input.name,
        enName: input.enName,
        description: input.description ?? null,
      });
      return { id: Number(result[0].insertId) };
    }),

  // Update partner
  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255),
        enName: z.string().min(1).max(255),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(partners).set(data).where(eq(partners.id, id));
      return { success: true };
    }),

  // Delete partner
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(partners).where(eq(partners.id, input.id));
      return { success: true };
    }),
});
