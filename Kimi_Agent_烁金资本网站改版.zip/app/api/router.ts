import { authRouter } from "./auth-router";
import { projectRouter } from "./project-router";
import { partnerRouter } from "./partner-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  project: projectRouter,
  partner: partnerRouter,
});

export type AppRouter = typeof appRouter;
